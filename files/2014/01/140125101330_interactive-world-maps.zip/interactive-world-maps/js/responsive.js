var delay = (function(){
  var timer = 0;
  return function(callback, ms){
    clearTimeout (timer);
    timer = setTimeout(callback, ms);
  };
})();


jQuery(window).on('resize orientationChanged', function() {

		jQuery('#map_canvas').animate({
		    opacity: 0,
		  }, 100, function() {
		    // Animation complete.
		  });

		delay(function(){
		     if (typeof iwmDrawVisualization == 'function') {
				     iwmDrawVisualization();
				     jQuery('#map_canvas').animate({
					    opacity: 1,
					  }, 100, function() {
					    // Animation complete.
					  });		 
				} 

		    }, 500);

});