<?php

$currPage = isset($_GET['paged']) ? $_GET['paged'] : 1;

//var_dump($localPayments);

$columns = array(
    'site_name' => 'Site Name',
    'account_name' => 'Account Name',
    'original_url' => 'Original URL',
    'payment' => 'Payment',
    'status' => 'Status',
    'cdate' => 'Create date',
);

$hidden = array();
$sortable = array(
    'site_name' => array('site_name',false),
    'account_name' => array('account_name',false),
    'payment' => array('payment',false),
    'status' => array('status',false),
    'cdate' => array('cdate',false),
);
$bulkActions = array(
);

$sortColumn = isset($_GET['orderby']) && array_key_exists($_GET['orderby'],$sortable) ? $_GET['orderby'] : 'cdate';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'asc';

$mdApiService = new MobilizeDudamobileTableApiService();
$localPayments = $mdApiService->getLocalPaymentsByPage($currPage, null, $sortColumn, $sortOrder);
$localPaymentsCountRows = $mdApiService->countLocalPayments();

$paymentsTable = new MobilizeDudamobileTable();
$paymentsTable->set_data($columns, $localPayments, $localPaymentsCountRows, $hidden, $sortable, $bulkActions);
$paymentsTable->prepare_items();
?>

<div class="wrap"><h2>Payments List</h2>
    <form action="" method="post">
        <input type="hidden" name="dudamobile-type" value="dudamobile-payments" />
        <?php
        $paymentsTable->display();
        ?>
    </form>
</div>

