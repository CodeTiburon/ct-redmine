(function($) {
	$.fn.mobilize = function(options) {
		var options = $.extend( {
			'key' : 'val'
		}, options);
		
		var isReady = false;
		var isComplete = false;
		
		var form = {
			loader: {
				show: function($form, self) {
					isReady = false;
					isComplete = false;
					$(self).find('.form-errors').remove();
					$(self).find('.mobilize-dudamobile-preview').remove();
					
					$form.hide();
					$form.siblings('.mobilize-loader')
//                            .css({
//						'height' : $form.height()
//					})
                            .removeClass('hidden').addClass('visible');
					
					var index = 0;
					var count = $form.siblings('.mobilize-loader').find('.items .item').length;
					var timer = setInterval(function() {
						if(index < count) {
							var $items = $form.siblings('.mobilize-loader').find('.items');
							$items.find('.item').removeClass('active');
							$items.find('.item[data-index="' + index + '"]').addClass('active');
							index++;
						} else {
							index = 0;
							isReady = true;
							clearInterval(timer);
						}
					}, 2000);
				},
				hide: function($form) {
					$form.show();
					$form.siblings('.mobilize-loader').find('.items .item').removeClass('active');
					$form.siblings('.mobilize-loader').removeClass('visible').addClass('hidden');
					isComplete = true;
				}
			},
			initialize: function(self) {
				var $this = this;
				var $form = $(self).find('form');
				$form.submit(function() {
					$this.loader.show($form, self);
					
					$.post($form.attr('data-action'), {
						url: document.URL,
						data: $form.serialize()
					}, function(response) {
						var timer = setInterval(function() {
							if(isReady == true && isComplete == false) {
								if(!response.success) {
									document.location = response.data.request_url;
								} else {
									$(self).find('.form-errors').remove();
									if(response.data.errors && response.data.errors.length) {
										$(self).prepend($('<ul>', {
											'class' : 'form-errors'
										}));
										$.each(response.data.errors, function(i,o) {
											$(self).find('.form-errors').append($('<li>', {
												'class' : 'error-item',
												'html' : o
											}));
										});
									}
									if(response.success == true && !response.data.errors) {
                                        if(response.data.redirect_editor_page !== undefined){
                                            document.location = response.data.url;
                                        }else{
                                            $(self).append($('<div>', {
                                                'class' : 'mobilize-dudamobile-preview',
                                                'html' : $('<iframe>', {
                                                    'src' : response.data.url
                                                })
                                            }));                                            
                                        }
									}
								}
								$this.loader.hide($form, self);
								clearInterval(timer);
							}
						}, 1000);
					}, 'json');
					return false;
				});
			}
		};
		
		return this.each(function() {
			form.initialize(this);
		});
	};
})(jQuery);
