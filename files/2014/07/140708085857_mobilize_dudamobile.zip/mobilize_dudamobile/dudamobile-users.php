<?php

$currPage = isset($_GET['paged']) ? $_GET['paged'] : 1;

//var_dump($localAccounts);

$usersColumns = array(
    'cb' => '<input type="checkbox" />',
    'account_name' => 'Account Name',
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'E-mail',
    'cdate' => 'Create date',
);

$usersHidden = array();
$usersSortable = array(
    'account_name' => array('account_name',false),
    'first_name' => array('first_name',false),
    'last_name' => array('last_name',false),
    'email' => array('email',false),
    'cdate' => array('cdate',false),
);
$usersBulkActions = array(
    'delete' => 'Delete'
);

$sortColumn = isset($_GET['orderby']) && array_key_exists($_GET['orderby'],$usersSortable) ? $_GET['orderby'] : 'cdate';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'asc';

$mdApiService = new MobilizeDudamobileTableApiService();
$localAccounts = $mdApiService->getLocalAccountsByPage($currPage, null, $sortColumn, $sortOrder);
$localAccountsCountRows = $mdApiService->countLocalAccounts();

$usersTable = new MobilizeDudamobileTable();
$usersTable->set_data($usersColumns, $localAccounts, $localAccountsCountRows, $usersHidden, $usersSortable, $usersBulkActions);
$usersTable->prepare_items();
?>

<div class="wrap"><h2>Accounts List</h2>
    <form action="" method="post">
        <input type="hidden" name="dudamobile-type" value="dudamobile-users" />
        <?php
        $usersTable->display();
        ?>
    </form>
</div>

