<?php

//if (!current_user_can('manage_options')) {
//    wp_die(__('You do not have sufficient permissions to access this page.'));
//}

$mdApiService = new MobilizeDudamobileTableApiService();

//$mdApiService->deleteMobileSite('pustunchik');

$localSites = $mdApiService->getRecentLocalSites();
$localSitesCountRows = count($localSites);

$recentPayments = $mdApiService->getRecentPayments();
$recentPaymentsCountRows = count($recentPayments);

$data = array(array('site_name' => 'thumbad_1'));

$recentSitesColumns = array(
    'cb' => '<input type="checkbox" />',
    'site_name' => 'Site name',
    'original_site_url' => 'Original Site URL',
    'site_domain' => 'Site domain',
    'auto_sync_cache_ttl' => 'Auto sync cache ttl',
    'site_vertical' => 'Site vertical',
    'site_vertical_category' => 'Site vertical category',
    'business_name' => 'Business name',
//    'address' => 'Address',
    'phone_number' => 'Phone number',
//    'opentable_info' => 'Opentable info',
    'preview_url' => 'Preview Site URL',
    'before_after_preview_url' => 'Before after preview url',
    'cdate' => 'Creation Date',
);

$recentSitesHidden = array();
$recentSitesSortable = array();
$recentSitesBulkActions = array(
    'delete' => 'Delete'
);
$recentSitesFormat = array(
    'original_site_url' => array(
        'type' => 'url',
//        'text' => 'Link',
        'target' => '_blank',
    ),
    'preview_url' => array(
        'type' => 'url',
        'text' => 'link',
        'target' => '_blank',
    ),
    'before_after_preview_url' => array(
        'type' => 'url',
        'text' => 'link',
        'target' => '_blank',
    ),
);

$recentPaymentsColumns = array(
    'site_name' => 'Site Name',
    'account_name' => 'Account Name',
    'original_url' => 'Original Site URL',
//    'external_uid' => 'External uid',
    'payment' => 'Amount',
    'status' => 'status',
    'cdate' => 'Date',
);
$recentPaymentsFormat = array(
    'original_url' => array(
        'type' => 'url',
//        'text' => 'link',
        'target' => '_blank',
    ),
);

$recentPaymentsHidden = array();
$recentPaymentsSortable = array();


$recentSitesTable = new MobilizeDudamobileTable();
$recentSitesTable->set_data($recentSitesColumns, $localSites, $localSitesCountRows, $recentSitesHidden, $recentSitesSortable, $recentSitesBulkActions, $recentSitesFormat);
$recentSitesTable->prepare_items();

$recentPaymentsTable = new MobilizeDudamobileTable();
$recentPaymentsTable->set_data($recentPaymentsColumns, $recentPayments, $recentPaymentsCountRows, $recentPaymentsHidden, $recentPaymentsSortable, null, $recentPaymentsFormat);
$recentPaymentsTable->prepare_items();
?>

<div class="wrap">
    <h2>Recently generated sites</h2>

    <form action="" method="post">
        <input type="hidden" name="dudamobile-type" value="dudamobile-sites" />
        <?php
        $recentSitesTable->display();
        ?>
    </form>
</div>

<div class="wrap">
    <h2>Recent payments</h2>

    <?php
    $recentPaymentsTable->display();
    ?>
</div>

