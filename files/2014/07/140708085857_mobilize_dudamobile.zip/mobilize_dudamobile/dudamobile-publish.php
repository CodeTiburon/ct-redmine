<?php

define('WP_USE_THEMES', false);
include($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

require_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if (!is_plugin_active('mobilize_dudamobile/mobilize_dudamobile.php')) {
	echo 'Plugin disabled!';
}

$siteName = isset($_GET['sitename']) ? $_GET['sitename'] : null;
$accountName = isset($_GET['accountname']) ? $_GET['accountname'] : null;
$originalUrl = isset($_GET['originalurl']) ? $_GET['originalurl'] : null;
$externalUid = isset($_GET['external_uid']) ? $_GET['external_uid'] : null;

if($siteName && $accountName && $originalUrl){

    $data = array(
        'site_name' => $siteName,
        'account_name' => $accountName,
        'original_url' => $originalUrl,
    );

    if(!empty($externalUid)){
        $data['external_uid'] = $externalUid;
    }

    $mdService = new MobilizeDudamobileApiService();
//    $published = $mdService->publishMobileSite($data, true);
    $published = $mdService->publishMobileSite($data);
    if($published === true){
        $site = $mdService->getMobileSite($data['site_name']);

        if(isset($site->site_name)){
            echo 'Congrulations!<br>';
            echo 'Before and after prewiew: <a href="'.$site->site_extra_info->before_after_preview_url.'" target="_blank">link</a><br>';
            echo 'Prewiew mobile site: <a href="'.$site->site_extra_info->preview_url.'" target="_blank">link</a><br>';

            if(isset($site->site_domain)){
                echo 'Mobile site domain: '.$site->site_domain;
            }
        }
    }
}else{
    echo '<b>Bad params!!!</b>';
}
