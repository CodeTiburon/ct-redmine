<?php

/**
 * @package Mobilize
 */

/*
Plugin Name: Mobilize Dudamobile
Plugin URI:
Description: The Mobilize DudaMobile mobile website builder WordPress plugin makes it incredibly easy to create a mobile-friendly version of your WordPress website.
Version: 1.1.0
Author: Ainstainer Software Development Teams
Author URI: http://www.ainstainer.com/
License:
*/

if(!function_exists('add_action')) {
	echo 'Hi there! I\'m just a plugin, not much I can do when called directly.';
	exit;
}

define('MOBILIZE_DUDAMOBILE_VERSION', '1.0.0');
define('MOBILIZE_DUDAMOBILE_PLUGIN_URL', plugin_dir_url( __FILE__ ));
define('MOBILIZE_DUDAMOBILE_PLUGIN_PATH', plugin_dir_path( __FILE__ ));

include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileError.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileSettings.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileShortcode.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileShortcodeEditor.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileShortcodeViewer.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileApiService.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileTable.php';
include_once MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'MobilizeDudamobileTableApiService.php';

function mobilize_dudamobile_is_ready() {
	$user = wp_get_current_user();

	$is_ready = true;

	$options = get_option('mobilize_dudamobile_settings');
	if(empty($options) || !is_array($options)) {
		$is_ready = false;
	} else {
		$keys = array(
            'dudamobile_api_endpoint',
            'dudamobile_api_username',
            'dudamobile_api_password',
            'dudamobile_sso_endpoint',
            'dudamobile_sso_username',
            'dudamobile_sso_password',
            'dudamobile_anonymous_email',
            'dudamobile_anonymous_firstname',
            'dudamobile_anonymous_lastname',
            'dudamobile_cache_time',

            );
		foreach ($keys as $key) {
			if(empty($options[$key]) || strlen(trim($options[$key])) < 1) {
				$is_ready = false;
				break;
			}
		}
	}

	return $is_ready;
}

function mobilize_dudamobile_activate() {
	global $wpdb;
}

register_activation_hook(__FILE__, 'mobilize_dudamobile_activate');

function mobilize_dudamobile_deactivation() {
	global $wpdb;

	delete_option('mobilize_dudamobile_settings');
}

register_deactivation_hook(__FILE__, 'mobilize_dudamobile_deactivation');

function mobilize_dudamobile_init() {
	$extension_loaded_curl = extension_loaded('curl');
	if(!$extension_loaded_curl) {
		define('MOBILIZE_DUDAMOBILE_ENVIRONMENT_READY', false);
	} else {
		define('MOBILIZE_DUDAMOBILE_ENVIRONMENT_READY', true);
	}

	if(!mobilize_dudamobile_is_ready()) {
		define('MOBILIZE_DUDAMOBILE_SETUP_READY', false);
	} else {
		define('MOBILIZE_DUDAMOBILE_SETUP_READY', true);
	}
    setcookie('show_cache_cleared_success_notice', 'false', time() - 60, '/');
    handle_request();
}

function handle_request() {
    $options = get_option('mobilize_dudamobile_settings');
    if (!empty($_POST)) {
        // only for users with `manage_options` permission
        if (isset($_POST['cache_expired']) and current_user_can('manage_options')) {
            $options['dudamobile_start_caching'] = time();
            $options['from_notice'] = true;
            update_option('mobilize_dudamobile_settings', $options);
            // redirect to referrer url (prevent form resubmit by F5)
            if (isset($_POST['referrer'])) {
                wp_redirect($_POST['referrer']);
            }
        }
    }
}

add_action('init', 'mobilize_dudamobile_init');

function mobilize_add_stylesheets() {
	wp_register_style('mobilize-dudamobile-stylesheet', plugins_url('styles/stylesheet.css', __FILE__) );
	wp_enqueue_style('mobilize-dudamobile-stylesheet');
}

add_action('wp_enqueue_scripts', 'mobilize_add_stylesheets');

function mobilize_add_scripts() {
	wp_deregister_script('jquery');
	wp_register_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js');
	wp_enqueue_script('jquery');

	wp_register_script('mobilize-dudamobile-script', plugins_url('scripts/mobilize-dudamobile.js', __FILE__) );
	wp_enqueue_script('mobilize-dudamobile-script');
}

add_action('wp_enqueue_scripts', 'mobilize_add_scripts');

function mobilize_dudamobile_admin_notices() {
	$user = wp_get_current_user();
    $options = get_option('mobilize_dudamobile_settings');

    $success = false;
    $error = false;

    $success_messages = array();
	$error_messages = array();
    $error_messages_with_form = array();


    if (isset($_COOKIE['show_cache_cleared_success_notice'])) {

        $success = true;
        $success_messages[] = sprintf(
            'The update was completed successfully %s, the next time you get a notice about the need to update %s.',
            date('Y-m-d H:i:s', $options['dudamobile_start_caching']),
            date('Y-m-d H:i:s', $options['dudamobile_start_caching'] + $options['dudamobile_cache_time'])
        );
    }

	if(!mobilize_dudamobile_is_ready()) {
		$error = true;
		$error_messages[] = sprintf('You need to setup your Mobilize Dudamobile API and SSO settings. Click <a href="%s">here</a> to setup your settings.', esc_url('/wp-admin/options-general.php?page=mobilize-dudamobile-settings'));
	}

	if(!extension_loaded('curl')) {
		$error = true;
		$error_messages[] = sprintf('Check your server settings, looks like a php %s extension not loaded or not configured properly.', 'curl');
	}

    // add update cache notice
    if (isset($_GET['page']) and
        // show this notice only on pages related to `dudamobile`
        strpos($_GET['page'], 'dudamobile') and
        isset($options['dudamobile_cache_time']) and
        time() - $options['dudamobile_start_caching'] > $options['dudamobile_cache_time']) {
        $error = true;
        $error_messages_with_form[] = sprintf(
            '
                <form action="%s" method="post">
                Cache was set at %s and expired at %s.
                Please update cache by clicking <button class="link" type="submit">here</button>
                or adjust the cache time in <a href="%s">settings</a>.
                    <input type="hidden" name="cache_expired" value="true">
                    <input type="hidden" name="referrer" value="%s">
                </form>
            ',
            $_SERVER["REQUEST_URI"],
            date('Y-m-d H:i:s', $options['dudamobile_start_caching']),
            date('Y-m-d H:i:s', $options['dudamobile_start_caching'] + $options['dudamobile_cache_time']),
            esc_url('/wp-admin/options-general.php?page=mobilize-dudamobile-settings'),
            $_SERVER["REQUEST_URI"]
        );
    }

	if ($error === true || $success === true and user_can($user, 'administrator')) {
        echo
        '
            <style>
                button.link {
                    background: none;
                    border: none;
                    color: #0074a2;
                    text-decoration: underline;
                    cursor: auto;
                    margin: 0;
                    padding: 0;
                }
                button.link:hover {
                    cursor: pointer;
                    color:#2ea2cc;
                }
                .error form {
                    margin: 10px 20px 10px 0;
                    color: #dd3d36;
                }
            </style>
        ';
        echo '<div class="wrap">';

        foreach ($success_messages as $message) {
            echo '<div class="updated"><p><strong>' . $message . '</strong></p></div>';
        }

		$error_message = '';

		foreach ($error_messages as $message) {
			$error_message .= '<p><strong>' . $message . '</strong></p>';
		}

        if ($error_message !== '') {
            echo '<div id="message" class="error">' . $error_message . '</div>';
        }

        foreach ($error_messages_with_form as $message) {
            echo '<div id="message" class="error">' . $message . '</div>';
        }
        echo '</div>';
	}
}

add_action('admin_notices', 'mobilize_dudamobile_admin_notices');

if(is_admin()) {
	$mobilizeDudamobileSettings = new MobilizeDudamobileSettings();
}

add_shortcode('mobilize_dudamobile_editor', array('MobilizeDudamobileShortcodeEditor', 'shortcode'));

add_shortcode('mobilize_dudamobile_viewer', array('MobilizeDudamobileShortcodeViewer', 'shortcode'));

function mobilize_rewrite_rules_array($rules) {
	global $wp_rewrite;

	return array('mobilize/(.+)' => 'index.php?mobilize=' . $wp_rewrite->preg_index(1)) + $rules;
}

add_filter('rewrite_rules_array', 'mobilize_rewrite_rules_array');

function mobilize_query_vars($vars) {
	$vars[] = 'mobilize';

	return $vars;
}

add_filter('query_vars', 'mobilize_query_vars');

function mobilize_admin_init() {
	global $wp_rewrite;
	$wp_rewrite->flush_rules();
}

add_filter('admin_init', 'mobilize_admin_init');

function mobilize_template_redirect() {
	global $wp_query;

    if ($wp_query->get('mobilize') && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
		!empty($_POST['url']) ? $request_url = (string) $_POST['url'] : $request_url = get_bloginfo('url');
		!empty($_POST['data']) ? parse_str($_POST['data'], $request_data) : $request_data = array();

		$response = array(
			'data' => array(
				'request_url' => $request_url,
				'errors' => array(),
			),
			'success' => true,
			'message' => '',
		);

		$mobilize = $wp_query->get('mobilize');
		switch ($mobilize) {
			case MobilizeDudamobileShortcodeEditor::getShortcodeKey():
				$result = MobilizeDudamobileShortcodeEditor::buildEditor($request_data, array(
					'editor_window' => 'self',
					'sub_account_validation' => 'skip',
				), true);

				$response['data']['errors'] = $result['errors'];

				if($result['success'] == true) {
					$response['data']['url'] = $result['sso_link'];
                    $response['data']['redirect_editor_page'] = true;
				}

				break;
			case MobilizeDudamobileShortcodeViewer::getShortcodeKey():
				$result = MobilizeDudamobileShortcodeViewer::buildViewer($request_data, array(
					'viewer_window' => 'self',
				), true);

				$response['data']['errors'] = $result['errors'];

				if($result['success'] == true) {
					$response['data']['url'] = $result['preview_url'];
				}

				break;
			default:
				$response['success'] = false;
				break;
		}

		wp_send_json($response);
		wp_die();
            }
        }

add_action('template_redirect', 'mobilize_template_redirect');

/* Add option page in admin menu */
if( ! function_exists( 'dudamobile_admin_menu' ) ) {
	function dudamobile_admin_menu() {
        add_menu_page( 'Dudamobile plugin dashboard', 'Dudamoble dashboard', 'manage_options', 'mobilize_dudamobile/dudamobile-dashboard.php','', MOBILIZE_DUDAMOBILE_PLUGIN_URL .'/images/icon.png');
		add_submenu_page('mobilize_dudamobile/dudamobile-dashboard.php', 'Dudamobile plugin users', 'Users', 'manage_options', 'mobilize_dudamobile/dudamobile-users.php' );
        add_submenu_page('mobilize_dudamobile/dudamobile-dashboard.php', 'Dudamobile plugin sites', 'Sites', 'manage_options', 'mobilize_dudamobile/dudamobile-sites.php' );
        add_submenu_page('mobilize_dudamobile/dudamobile-dashboard.php', 'Dudamobile plugin payments', 'Payments', 'manage_options', 'mobilize_dudamobile/dudamobile-payments.php' );
	}
}

add_action( 'admin_menu', 'dudamobile_admin_menu' );

function mobilize_dudamobile_activation()
{
    global $wpdb;
    global $mobilize_db_version;

    $tableNames = array(
        'md_accounts' => $wpdb->prefix . 'md_accounts',
        'md_sites' => $wpdb->prefix . 'md_sites',
        'md_accounts_sites' => $wpdb->prefix . 'md_accounts_sites',
        'md_payments' => $wpdb->prefix . 'md_payments',
    );

    add_option('mobilize_db_tables', $tableNames);

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    foreach($tableNames as $tableKey => $tableName){
        if ($wpdb->get_var("show tables like '$tableName'") != $tableName) {

            switch ($tableKey) {
                case 'md_accounts_sites':
                    $sql = "CREATE TABLE " . $tableName . " (
                        id INT(11) NOT NULL AUTO_INCREMENT,
                        account_name VARCHAR(255) NOT NULL,
                        site_name VARCHAR(255) NOT NULL,
                        cdate DATETIME DEFAULT NULL,
                        status VARCHAR(255) DEFAULT NULL,
                        UNIQUE KEY account_site (account_name, site_name),
                        PRIMARY KEY id (id)
                      );";
                    break;
                case 'md_accounts':
                    $sql = "CREATE TABLE " . $tableName . " (
                        id INT(11) NOT NULL AUTO_INCREMENT,
                        account_name VARCHAR(255) NOT NULL,
                        first_name VARCHAR(255) NOT NULL,
                        last_name VARCHAR(255) NOT NULL,
                        email VARCHAR(255) NOT NULL,
                        cdate DATETIME DEFAULT NULL,
                        UNIQUE KEY account_name (account_name),
                        PRIMARY KEY id (id)
                      );";
                    break;
                case 'md_sites':
                    $sql = "CREATE TABLE " . $tableName . " (
                        id INT(11) NOT NULL AUTO_INCREMENT,
                        site_name VARCHAR(255) NOT NULL,
                        original_site_url VARCHAR(255) DEFAULT NULL,
                        site_domain VARCHAR(255) DEFAULT NULL,
                        auto_sync_cache_ttl VARCHAR(255) DEFAULT NULL,
                        site_vertical VARCHAR(255) DEFAULT NULL,
                        site_vertical_category VARCHAR(255) DEFAULT NULL,
                        business_name TEXT DEFAULT NULL,
                        address TEXT DEFAULT NULL,
                        phone_number VARCHAR(255) DEFAULT NULL,
                        opentable_info TEXT DEFAULT NULL,
                        preview_url TEXT DEFAULT NULL,
                        before_after_preview_url TEXT DEFAULT NULL,
                        cdate DATETIME DEFAULT NULL,
                        UNIQUE KEY site_name (site_name),
                        PRIMARY KEY id (id)
                      );";
                    break;
                case 'md_payments':
                    $sql = "CREATE TABLE " . $tableName . " (
                        id INT(11) NOT NULL AUTO_INCREMENT,
                        site_name VARCHAR(255) NOT NULL,
                        account_name VARCHAR(255) NOT NULL,
                        original_url TEXT NOT NULL,
                        external_uid TEXT DEFAULT NULL,
                        payment DECIMAL (10,2) DEFAULT '0.0',
                        status VARCHAR(255) DEFAULT NULL,
                        cdate DATETIME DEFAULT NULL,
                        UNIQUE KEY id (id)
                      );";
                    break;
            }
            dbDelta($sql);
        }
    }
}
register_activation_hook(__FILE__, 'mobilize_dudamobile_activation');

function mobilize_dudamobile_mydeactivation()
{
    delete_option('mobilize_db_tables');
}
register_deactivation_hook(__FILE__, 'mobilize_dudamobile_mydeactivation');
