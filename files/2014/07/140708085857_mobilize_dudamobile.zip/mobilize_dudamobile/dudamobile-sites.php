<?php
$currPage = isset($_GET['paged']) ? $_GET['paged'] : 1;

$columns = array(
    'cb' => '<input type="checkbox" />',
    'site_name' => 'Site name',
    'original_site_url' => 'Original Site URL',
    'site_domain' => 'Site domain',
    'auto_sync_cache_ttl' => 'Auto sync cache ttl',
    'site_vertical' => 'Site vertical',
    'site_vertical_category' => 'Site vertical category',
    'business_name' => 'Business name',
//    'address' => 'Address',
    'phone_number' => 'Phone number',
//    'opentable_info' => 'opentable_info',
    'preview_url' => 'Preview Site URL',
    'before_after_preview_url' => 'before_after_preview_url',
    'cdate' => 'Creation Date',
);

$hidden = array();
$sortable = array(
    'site_name' => array('site_name',false),
    'site_domain' => array('site_domain',false),
    'site_vertical' => array('site_vertical',false),
    'site_vertical_category' => array('site_vertical_category',false),
    'business_name' => array('business_name',false),
    'cdate' => array('cdate',false),
);
$bulkActions = array(
    'delete' => 'Delete'
);


$sortColumn = isset($_GET['orderby']) && array_key_exists($_GET['orderby'],$sortable) ? $_GET['orderby'] : 'cdate';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'asc';

$mdApiService = new MobilizeDudamobileTableApiService();
$localSitesCountRows = $mdApiService->countLocalSites();

$localSites = $mdApiService->getLocalSitesByPage($currPage, null, $sortColumn, $sortOrder);

$format = array(
    'original_site_url' => array(
        'type' => 'url',
//        'text' => 'Link',
        'target' => '_blank',
    ),
    'preview_url' => array(
        'type' => 'url',
        'text' => 'link',
        'target' => '_blank',
    ),
    'before_after_preview_url' => array(
        'type' => 'url',
        'text' => 'link',
        'target' => '_blank',
    ),
);

$sitesTable = new MobilizeDudamobileTable();
$sitesTable->set_data($columns, $localSites, $localSitesCountRows, $hidden, $sortable, $bulkActions, $format);
$sitesTable->prepare_items();
?>

<div class="wrap">
    <h2>Sites</h2>

    <form action="" method="post">
        <input type="hidden" name="dudamobile-type" value="dudamobile-sites" />
        <?php
        $sitesTable->display();
        ?>
    </form>
</div>