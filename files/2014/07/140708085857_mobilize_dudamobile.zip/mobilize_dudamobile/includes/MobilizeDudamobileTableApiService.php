<?php


class MobilizeDudamobileTableApiService extends MobilizeDudamobileApiService
{
    public function countLocalAccounts(){
        global $wpdb;
        $sql = 'SELECT COUNT(id) FROM '.$this->_db_tables['md_accounts'];

        return $wpdb->get_var($sql);
    }
    public function getLocalAccountsByPage($pageId = 1, $perPage = null, $sortColumn = null, $sortOrder = null){
        global $wpdb;
        $limit = empty($perPage) ? (int)get_option('posts_per_page') : $perPage;
        $sortColumn = !empty($sortColumn) ? strip_tags($sortColumn) : 'id';
        $sortOrder = ($sortOrder === 'desc') ? strip_tags($sortOrder) : 'asc';
        $page = (int)$pageId;
        if($page > 0) {
            $page = (($page - 1) * $limit);
        }
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_accounts'].' ORDER BY '.$sortColumn.' '.$sortOrder.' LIMIT %d, %d', $page, $limit);

        return $wpdb->get_results($prepare, ARRAY_A);
    }
    public function getRecentLocalAccounts($limit = null) {
        global $wpdb;
        $limit = empty($limit) ? (int)get_option('posts_per_page') : $limit;
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_accounts'].' ORDER BY id DESC LIMIT 0, %d', $limit);

        return $wpdb->get_results($prepare, ARRAY_A);
    }
    public function countLocalSites(){
        global $wpdb;
        $sql = 'SELECT COUNT(id) FROM '.$this->_db_tables['md_sites'];

        return $wpdb->get_var($sql);
    }
    public function getLocalSitesByPage($pageId = 1, $perPage = null, $sortColumn = null, $sortOrder = null){
        global $wpdb;
        $limit = empty($perPage) ? (int)get_option('posts_per_page') : $perPage;
        $sortColumn = !empty($sortColumn) ? strip_tags($sortColumn) : 'id';
        $sortOrder = ($sortOrder === 'desc') ? strip_tags($sortOrder) : 'asc';
        $page = (int)$pageId;
        if($page > 0) {
            $page = (($page - 1) * $limit);
        }
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_sites'].' ORDER BY '.$sortColumn.' '.$sortOrder.' LIMIT %d, %d', $page, $limit);

        return $wpdb->get_results($prepare, ARRAY_A);
    }
    public function getRecentLocalSites($limit = null) {
        global $wpdb;
        $limit = empty($limit) ? (int)get_option('posts_per_page') : $limit;
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_sites'].' ORDER BY cdate DESC LIMIT 0, %d', $limit);

        return $wpdb->get_results($prepare, ARRAY_A);
    }
    public function countLocalPayments(){
        global $wpdb;
        $sql = 'SELECT COUNT(id) FROM '.$this->_db_tables['md_payments'];

        return $wpdb->get_var($sql);
    }
    public function getLocalPaymentsByPage($pageId = 1, $perPage = null, $sortColumn = null, $sortOrder = null){
        global $wpdb;
        $limit = empty($perPage) ? (int)get_option('posts_per_page') : $perPage;
        $sortColumn = !empty($sortColumn) ? strip_tags($sortColumn) : 'id';
        $sortOrder = ($sortOrder === 'desc') ? strip_tags($sortOrder) : 'asc';
        $page = (int)$pageId;
        if($page > 0) {
            $page = (($page - 1) * $limit);
        }
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_payments'].' ORDER BY '.$sortColumn.' '.$sortOrder.' LIMIT %d, %d', $page, $limit);

        return $wpdb->get_results($prepare, ARRAY_A);
    }
    public function getRecentPayments($limit = null) {
        global $wpdb;
        $limit = empty($limit) ? (int)get_option('posts_per_page') : $limit;
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_payments'].' ORDER BY cdate DESC LIMIT 0, %d', $limit);

        return $wpdb->get_results($prepare, ARRAY_A);
    }
}
