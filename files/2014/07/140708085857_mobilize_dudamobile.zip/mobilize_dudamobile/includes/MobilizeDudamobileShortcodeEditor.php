<?php

class MobilizeDudamobileShortcodeEditor extends MobilizeDudamobileShortcode {
	public function __construct() {
		parent::__construct();
	}

	public static function getAction() {
		return parent::getAction(array(
			'key' => 'mobilize',
			'value' => self::getShortcodeKey(),
		));
	}

	public static function getShortcodeKey() {
		return md5('mobilize_dudamobile_shortcode_editor') . '-' . md5(date('d', time()));
	}

	public static function shortcode($atts, $content = '') {
		global $wpdb;

		if(!MOBILIZE_DUDAMOBILE_ENVIRONMENT_READY || !MOBILIZE_DUDAMOBILE_SETUP_READY) {
			ob_start();
			require parent::getTemplatesDirectory() . 'error.tpl.php';
			return ob_get_clean();
		}

		$shortcode_key = self::getShortcodeKey();

		extract(shortcode_atts(array(
			'editor_window' => 'self',
			'sub_account_validation' => 'skip',
		), $atts));

		$form = array();
		$errors = array();
		$result = array(
			'form' => array(
				'url',
				'email',
				'fname',
				'lname',
			),
		);

		$sso_link = null;

		$request_data = $_POST;

		if (isset($request_data['mobilize_dudamobile_registration']) && $request_data['mobilize_dudamobile_registration']['shortcode_key'] == $shortcode_key) {
			$output = self::buildEditor($request_data, array(
				'editor_window' => isset($editor_window) ? $editor_window : 'self',
				'sub_account_validation' => isset($sub_account_validation) ? $sub_account_validation : 'skip',
			));

			$errors = $output['errors'];
			$result['form'] = $output['form'];
			$sso_link = $output['sso_link'];
		}

        $action = self::getAction();
        $isEditor = true;

		ob_start();
		require parent::getTemplatesDirectory() . 'registration.tpl.php';
		return ob_get_clean();
	}

	public static function buildEditor($request_data, $options = array(), $isAjaxCall = false) {
		$output = array(
			'success' => false,
		);

		!empty($options['editor_window']) ? $editor_window = (string) $options['editor_window'] : $editor_window = 'self';
		!empty($options['sub_account_validation']) ? $sub_account_validation = (string) $options['sub_account_validation'] : $sub_account_validation = 'skip';

		$form = $request_data['mobilize_dudamobile_registration'];

		if(!empty($form['url'])) {
			$form['url'] = 'http://' . str_replace(array('http://', 'www.', ), array('', '', ), $form['url']);
		}

        $mobilizeOptions = get_option('mobilize_dudamobile_settings');
        //$form['email'] = $mobilizeOptions['dudamobile_anonymous_email'];
        $form['fname'] = $mobilizeOptions['dudamobile_anonymous_firstname'];
        $form['lname'] = $mobilizeOptions['dudamobile_anonymous_lastname'];

        $output['form'] = $form;

		$result = parent::validator($form, 'registration');

		$sso_link = null;

		$output['errors'] = $result['error']->getErrorByKey('registration');

		if(empty($output['errors'])) {
            $mdApiService = new MobilizeDudamobileApiService();

            $insAccData = array(
                'account_name' => $result['form']['email'],
                'first_name' => $result['form']['fname'],
                'last_name' => $result['form']['lname'],
                'email' => $result['form']['email'],
            );
            $account = $mdApiService->createAccount($insAccData);

            if (isset($account->error_code)) {
                return $mdApiService->getCustomErrors($account, $isAjaxCall);
            }

            $site = $mdApiService->createMobileSite($result['form']['url']);

            if (isset($site->error_code)) {
                return $mdApiService->getCustomErrors($site, $isAjaxCall);
            }

            $grantAccess = $mdApiService->grantAccess($account->account_name, $site->site_name);

            if (isset($grantAccess->error_code)) {
                return $mdApiService->getCustomErrors($grantAccess, $isAjaxCall);
            }

            $output['sso_link'] = $mdApiService->getSsoEditorLink($account->account_name, $site->site_name);
            $output['success'] = true;
        }

        $output['editor_window'] = $editor_window;
        $output['sub_account_validation'] = $sub_account_validation;

        return $output;
	}
}
