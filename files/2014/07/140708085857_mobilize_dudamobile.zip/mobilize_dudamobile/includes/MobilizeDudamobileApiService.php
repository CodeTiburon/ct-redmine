<?php
/**
 * Description of MobilizeDudamobileApiService
 *
 * @author veber
 */
class MobilizeDudamobileApiService extends MobilizeDudamobileShortcode
{
    protected $_url;
    protected $_username;
    protected $_password;
    protected $_ssoEndpoint;
    protected $_ssoUsername;
    protected $_ssoPassword;
    protected $_serviceErrors;
    protected $_db_tables;


    // Wifigsm response error codes
    const ERROR_INVALID_REQUEST_PARAMS = 12;
    const ERROR_INVALID_API_PARAMS = 13;
    const ERROR_CURL = 98;
    const ERROR_INTERNAL = 99; // The internal error occurs on the server
    const ERROR_UNAUTHORIZED = 401;

    protected static $ERROR_MESSAGES = array(
        self::ERROR_INVALID_REQUEST_PARAMS => 'Invalid request params',
        self::ERROR_INVALID_API_PARAMS => 'Invalid API params',
        self::ERROR_INTERNAL => 'Internal server error',
//        self::ERROR_UNAUTHORIZED => 'The supplied credentials, if any, are not sufficient to access the resource.',
    );

	public function __construct()
    {
		parent::__construct();
        $this->_url = $this->getSettingsByKey('dudamobile_api_endpoint');
        $this->_username = $this->getSettingsByKey('dudamobile_api_username');
        $this->_password = $this->getSettingsByKey('dudamobile_api_password');
        $this->_ssoEndpoint = $this->getSettingsByKey('dudamobile_sso_endpoint');
        $this->_ssoUsername = $this->getSettingsByKey('dudamobile_sso_username');
        $this->_ssoPassword = $this->getSettingsByKey('dudamobile_sso_password');
        $this->_db_tables = get_option('mobilize_db_tables');

	}

    public function execute($path, array $params, $req, $notReturnedContent = false)
    {
        try {
            $result = $this->curlReq($path, $params, $req, $notReturnedContent);
        } catch (Exception $e) {
            $result = new stdClass();
            $result->error_code = $e->getCode();
            $result->message = $e->getMessage();
        }

        return $result;
    }

    public function createAccount(array $accInsData)
    {
        $account = $this->getAccount($accInsData['account_name']);

        if (!isset($account->account_name)) {
            $createdUser = $this->creatingAccount(
                    array(
                        'account_name' => $accInsData['account_name'],
                        'first_name' => $accInsData['first_name'],
                        'last_name' => $accInsData['last_name'],
                        'email' => $accInsData['email'],
                    )
            );

            if(isset($createdUser->error_code)){
                  return $createdUser;
            }

            $account = $this->getAccount($accInsData['account_name']);
        }

        if(!isset($account->error_code)){
            $this->insertNewAccount($account);
        }

        return $account;
    }

    public function createMobileSite($url)
    {
        $createMobileSite = $this->creatingMobileSite(
                array('site_data' => array('original_site_url' => $url))
        );

        if(isset($createMobileSite->error_code)){
            return $createMobileSite;
        }


        $mobileSite = $this->gettingMobileSite($createMobileSite->site_name);

        $this->insertNewMobileSite($mobileSite);

        return $mobileSite;
    }

    public function grantAccess($userName, $siteName)
    {
        $grantAccess = $this->grantingAccess($userName, $siteName);

        if($grantAccess == true){
            $this->insertNewAccountSite($userName, $siteName);
        }

        return $grantAccess;
    }

    public function getMobileSite($siteName)
    {
        $site = $this->gettingMobileSite($siteName);

        return $site;
    }

    public function publishMobileSite($data, $testMode = false)
    {
        $localAccount = $this->getLocalAccount($data['account_name']);
        $localSite = $this->getLocalSite($data['site_name']);

        if(!isset($localAccount->account_name) || !isset($localSite->site_name)){
            return false;
        }
        $publishSite = $this->publishingMobileSite($data['site_name'], $testMode);

        if($publishSite == true){
            $data['status'] = $testMode ? 'test' : 'publish';
            $this->insertNewPayment($data);
        }

        return $publishSite;
    }

    public function getCustomErrors($errorInfo, $isAjaxCall)
    {
        $error = new MobilizeDudamobileError();
        $error->setErrorByKey('errorsDudamobileApi', 'Error code: '.$errorInfo->error_code);
        $error->setErrorByKey('errorsDudamobileApi', $errorInfo->message);

        $errors = $error->getErrorByKey('errorsDudamobileApi');

        if($isAjaxCall == false) {
            ob_start();
            require parent::getTemplatesDirectory() . 'registration.tpl.php';
            return ob_get_clean();
        } else {
            $output['errors'] = $errors;
            return $output;
        }
    }

    /**
     * Updated all info in current site and api dudamobile
     * @access public
     * @global type $wpdb
     * @param bool $from_notice
     * @return bool
     */
    public function updateAllInfo($from_notice = false)
    {
        global $wpdb;

        // update api sites
        $mdTableSites = $this->_db_tables['md_sites'];
        $sites = $wpdb->get_results('SELECT id, site_name FROM ' . $mdTableSites);
        if (count($sites)) {
            $deleteSites = array();

            foreach ($sites as $site) {
                $isSite = $this->gettingMobileSite($site->site_name);

                if (isset($isSite->error_code)
                        &&
                    in_array($isSite->error_code, array('ResourceNotExist','AccessForbidden') )) {
                    array_push($deleteSites, $site->id);
                }
            }

            if (count($deleteSites)) {
                $whereDelSites = 'id IN (' . implode(',', $deleteSites) . ')';
                $wpdb->delete($mdTableSites, $whereDelSites);
            }
        }

        // update api users
        $mdTableAccounts = $this->_db_tables['md_accounts'];
        $users = $wpdb->get_results('SELECT account_name FROM ' . $mdTableAccounts);

        if (count($users)) {
            $deleteUsers = array();

            foreach ($users as $user) {
                $isUser = $this->getAccount($user->account_name);

                if (isset($isUser->error_code) && $isUser->error_code == 'ResourceNotExist') {
                    array_push($deleteUsers, $user->id);
                }
            }

            if (count($deleteUsers)) {
                $whereDelUsers = 'id IN (' . implode(',', $deleteUsers) . ')';
                $wpdb->delete($mdTableAccounts, $whereDelUsers);
            }
        }

        // update account_user
        $this->deleteNotExistAccountsSites();

        return true;
    }

    protected function deleteNotExistAccountsSites()
    {
        global $wpdb;

        $mdTableAccountsSites = $this->_db_tables['md_accounts_sites'];
        $mdTableAccounts = $this->_db_tables['md_accounts'];
        $mdTableSites = $this->_db_tables['md_sites'];

        $deleteAccountsUser = 'DELETE FROM '.$mdTableAccountsSites;
        $deleteAccountsUser .= ' WHERE account_name NOT IN (SELECT account_name FROM '.$mdTableAccounts.')';
        $deleteAccountsUser .= ' OR site_name NOT IN (SELECT site_name FROM '.$mdTableSites.')';

        return $wpdb->query($deleteAccountsUser);
    }

    public function getLocalAccounts()
    {
        global $wpdb;
        $sql = 'SELECT * FROM '.$this->_db_tables['md_accounts'];

        return $wpdb->get_results($sql, ARRAY_A);
    }

    public function getLocalSites()
    {
        global $wpdb;
        $sql = 'SELECT * FROM '.$this->_db_tables['md_sites'];

        return $wpdb->get_results($sql, ARRAY_A);
    }

    public function getLocalSite($siteName)
    {
       global $wpdb;
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_sites'].' WHERE site_name = %s', $siteName);

        return $wpdb->get_row($prepare);
    }

    public function getLocalAccount($accountName)
    {
       global $wpdb;
        $prepare = $wpdb->prepare('SELECT * FROM '.$this->_db_tables['md_accounts'].' WHERE account_name = %s', $accountName);

        return $wpdb->get_row($prepare);
    }

    public function deleteMobileSite($siteName)
    {
        global $wpdb;
        $result = $this->deletingMobileSite($siteName);

        if( $result === true
                ||
            $result->error_code == 'ResourceNotExist'
                ||
            $result->error_code == 'AccessForbidden'
                ){
            $mdSites = $this->_db_tables['md_sites'];
            $wpdb->delete( $mdSites, array('site_name' => $siteName), array('%s'));
            $this->deleteNotExistAccountsSites();
        }

        return $result;
    }

    public function deleteAccount($accountName)
    {
        global $wpdb;
        $result = $this->deletingAccount($accountName);

        if($result === true || $result->error_code == 'ResourceNotExist'){
            $mdAccounts = $this->_db_tables['md_accounts'];
            $wpdb->delete( $mdAccounts, array('account_name' => $accountName), array('%s'));
            $this->deleteNotExistAccountsSites();
        }

        return $result;
    }

    public function getSsoEditorLink($accountName, $siteName)
    {
        $ssoEndpoint = $this->_ssoEndpoint;
        $dm_sig_site = $siteName;
        $dm_sig_user = $accountName;
        $dm_sig_key = $this->_ssoUsername;
        $dm_sig_timestamp = time();
        $secret_key = $this->_ssoPassword;
        $dm_sig_string = $secret_key.'user='.$dm_sig_user.'timestamp='.$dm_sig_timestamp.'site='.$dm_sig_site.'partner_key='.$dm_sig_key;
        $dm_sig = hash_hmac('sha1', $dm_sig_string, $secret_key);
        $sso_link = 'http://'.$ssoEndpoint.'/home/site/'.$dm_sig_site.'?dm_sig_partner_key='.$dm_sig_key.'&dm_sig_timestamp='.$dm_sig_timestamp.'&dm_sig_user='.$dm_sig_user.'&dm_sig_site='.$dm_sig_site.'&dm_sig='.$dm_sig;
        return $sso_link;
        /** End: Opening the branded editor using SSO **/
    }

    protected function deletingMobileSite($siteName)
    {
        $pathParam = '/sites/mobile/'.$siteName;
        $result = $this->execute($pathParam, array(), 'DELETE', true);

        return $result;
    }

    protected function deletingAccount($accountName)
    {
        $pathParam = '/accounts/'.$accountName;
        $result = $this->execute($pathParam, array(), 'DELETE', true);

        return $result;
    }

    protected function publishingMobileSite($siteName, $testMode)
    {
        $pathParam = '/sites/mobile/publish/'.$siteName;
        $pathParam .= $testMode ? '?test=true' : '';
        $result = $this->execute($pathParam, array(), 'POST', true);
        return $result;
    }

    protected function getAccount($accountName)
    {
        $pathParam = '/accounts/'.$accountName;
        $result = $this->execute($pathParam, array(), 'GET');
        return $result;
    }

    protected function creatingAccount($data)
    {
        if(!isset($data['account_name'])){
            return false;
        }

        $insertedColumns = array(
            'account_name',
            'first_name',
            'last_name',
            'email',
            'lang',
        );
        $insertData = array();

        foreach ($insertedColumns as $column) {

            if(isset($data[$column])){

                $insertData[$column] = $data[$column];
            }
        }

        return $this->execute('/accounts/create', $insertData, 'POST', true);
    }

    protected function creatingMobileSite($data)
    {
        if(!isset($data['site_data'])){
            return false;
        }

        $siteData = $data['site_data'];

        if(!isset($siteData['original_site_url'])){
            return false;
        }

        $inputParams = array(
            'site_data' => $siteData,
        );

        if(isset($data['publish_now'])){
            $inputParams['publish_now'] = $data['publish_now'];
        }

        if(isset($data['create_now'])){
            $inputParams['create_now'] = $data['create_now'];
        }
        return $this->execute('/sites/mobile/create', $inputParams, 'POST');
    }

    protected function grantingAccess($userName, $siteName)
    {
        $pathParams = '/accounts/grant-access/'.$userName.'/sites/'.$siteName;
        return $this->execute($pathParams, array(), 'POST', true);
    }

    protected function gettingMobileSite($siteName)
    {
        $pathParams = '/sites/mobile/'.$siteName;
        return $this->execute($pathParams, array(), 'GET');
    }

    protected function insertNewAccount($account)
    {
        global $wpdb;
        $table_names = get_option('mobilize_db_tables');

        $insertData = array(
            'account_name' => $account->account_name,
            'first_name' => $account->first_name,
            'last_name' => $account->last_name,
            'email' =>$account->email,
            'cdate' => current_time('mysql'),
        );

        $rows_affected = $wpdb->insert($this->_db_tables['md_accounts'], $insertData);
        return $rows_affected;
    }

    protected function insertNewMobileSite($mobileSite)
    {
        global $wpdb;

        $insertedColumns = array(
            'site_name',
            'original_site_url',
            'site_domain',
            'auto_sync_cache_ttl',
            'site_vertical',
            'site_vertical_category',
            'site_business_info',
            'site_extra_info',
        );
        $insertData = array();

        foreach ($insertedColumns as $column) {

            if(isset($mobileSite->$column)){
                $currColumn = $mobileSite->$column;
                if($column == 'site_extra_info'){
                    $insertData['preview_url'] = $currColumn->preview_url;
                    $insertData['before_after_preview_url'] = $currColumn->before_after_preview_url;
                }elseif($column == 'site_business_info'){
                    $insertData['business_name'] = $currColumn->business_name;
                    $insertData['address'] = json_encode($currColumn->address);
                    $insertData['phone_number'] = $currColumn->phone_number;
                    $insertData['opentable_info'] = json_encode($currColumn->opentable_info);
                }else{
                    $insertData[$column] =  $currColumn;
                }
            }
        }

        if(count($insertData) == 0){
            return false;
        }

        $insertData['cdate'] = current_time('mysql');
        $rows_affected = $wpdb->update($this->_db_tables['md_sites'], $insertData, array('site_name' => $insertData['site_name']));

        if ( ! $rows_affected){
            $rows_affected = $wpdb->insert($this->_db_tables['md_sites'], $insertData);
        }

        return $rows_affected;
    }

    protected function insertNewAccountSite($accountName, $siteName)
    {
        global $wpdb;

        $insertData = array(
            'account_name' => $accountName,
            'site_name' => $siteName,
            'cdate' => current_time('mysql'),
        );

        $rows_affected = $wpdb->insert($this->_db_tables['md_accounts_sites'], $insertData);

        return $rows_affected;
    }

    protected function insertNewPayment($data)
    {
        global $wpdb;

        $insertData = array(
            'account_name' => $data['account_name'],
            'site_name' => $data['site_name'],
            'original_url' => $data['original_url'],
            'status' => $data['status'],
            'payment' => 0,
            'cdate' => current_time('mysql'),
        );

        if(isset($data['external_uid']) && !empty($data['external_uid'])){
            $insertData['external_uid'] = $data['external_uid'];
        }
        $rows_affected = $wpdb->insert($this->_db_tables['md_payments'], $insertData);

        return $rows_affected;
    }

    protected function curlReq($path, $params, $req, $notReturnedContent)
    {
        if (empty($this->_url) || empty($this->_username) || empty($this->_password)) {
            throw new Exception(self::$ERROR_MESSAGES[self::ERROR_INVALID_API_PARAMS], self::ERROR_INVALID_API_PARAMS);
        }

        if (!in_array($req, array('GET', 'POST', 'DELETE'))) {
            throw new Exception(self::$ERROR_MESSAGES[self::ERROR_INVALID_REQUEST_PARAMS], self::ERROR_INVALID_REQUEST_PARAMS);
        }

        $url = rtrim($this->_url, '/') . '/api' . $path;

        if(count($params) && $req=='GET'){
            $url .= '?'. http_build_query($params);
        }

        $jsonData = json_encode($params);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERPWD, $this->_username . ':' . $this->_password);
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $req);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        if ($req == 'POST') {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Content-Length: ' . strlen($jsonData)));
        $result = curl_exec($ch);
		$info = curl_getinfo($ch);

        if($info['http_code'] == 401){
            throw new Exception(self::$ERROR_MESSAGES[self::ERROR_INTERNAL], self::ERROR_INTERNAL);
        }else if ($info['http_code'] == 204 && $notReturnedContent){
            return true;
        }

        if (curl_errno($ch)) {
            throw new Exception(self::$ERROR_MESSAGES[self::ERROR_INTERNAL], self::ERROR_INTERNAL);
        }
        curl_close($ch);

        $responseData = @json_decode($result);
        if (empty($responseData)) {
            throw new Exception(self::$ERROR_MESSAGES[self::ERROR_INTERNAL], self::ERROR_INTERNAL);
        }

        return $responseData;
    }
}
