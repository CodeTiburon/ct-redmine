<div class="mobilize-dudamobile-form">
	<h3>A new mobile site in minutes</h3>
	<div class="legend"><p>All of your content is automatically gathered from your site (and any other pages you have on the web) and organized seamlessly to create a beautiful new mobile website for your business.</p></div>
	<div id="<?php echo 'mobilize-dudamobile-' . $shortcode_key; ?>">
		<?php if(!empty($errors)): ?>
		<ul class="form-errors">
			<?php foreach ($errors as $error): ?>
			<li class="error-item"><?php echo $error; ?></li>
			<?php endforeach; ?>
		</ul>
		<?php endif; ?>
		<form action="" class="mobilize-dudamobile-registration-form" method="post" role="registration" data-action="<?php echo $action; ?>">
			<input type="hidden" value="<?php echo $shortcode_key; ?>" name="mobilize_dudamobile_registration[shortcode_key]" />
			<div class="mobilize-dudamobile-form-item">
                <input type="text" title="Enter your site URL" name="mobilize_dudamobile_registration[url]" value="<?php echo esc_attr($result['form']['url']); ?>" placeholder="Enter your site URL" class="mobilize-dudamobile-field mobilize-dudamobile-field-url" />
			</div>
            <?php if(isset($isEditor)): ?>
                <div class="mobilize-dudamobile-form-item">
                    <input type="text" title="Enter your email address" name="mobilize_dudamobile_registration[email]" value="<?php echo esc_attr($result['form']['email']); ?>" placeholder="Enter your email address" class="mobilize-dudamobile-field mobilize-dudamobile-field-email" />
                </div>
            <?php endif;
            /*<div class="mobilize-dudamobile-form-item">
				<input type="text" title="Enter your first name" name="mobilize_dudamobile_registration[fname]" value="<?php echo esc_attr($result['form']['fname']); ?>" placeholder="Enter your first name" class="mobilize-dudamobile-field mobilize-dudamobile-field-firstname" />
			</div>
			<div class="mobilize-dudamobile-form-item">
				<input type="text" title="Enter your last name" name="mobilize_dudamobile_registration[lname]" value="<?php echo esc_attr($result['form']['lname']); ?>" placeholder="Enter your site last name" class="mobilize-dudamobile-field mobilize-dudamobile-field-lastname" />
			</div>*/?>
			<div class="mobilize-dudamobile-form-submit">
				<input type="submit" value="Create mobile preview" class="mobilize-dudamobile-submit" />
			</div>
			<div class="mobilize-dudamobile-form-item">
				<p class="note"><strong>*</strong> <em>This will not affect your desktop site</em></p>
			</div>
		</form>
		<div class="mobilize-loader hidden">
			<div class="icon"></div>
			<div class="message">
				<p><strong>Building</strong> <span>Your new mobile website</span></p>
				<div class="items">
					<div class="item" data-index="0">HTML &amp; CSS</div>
					<div class="item" data-index="1">Extracting Navigation, Color &amp; Content</div>
					<div class="item" data-index="2">Testing Your mobile website</div>
				</div>
			</div>
		</div>
	  <script type="text/javascript">
		//<![CDATA[
			jQuery(document).ready(function($) {
				$('<?php echo '#mobilize-dudamobile-' . $shortcode_key; ?>').mobilize();
			});
		//]]>
	  </script>
  </div>
</div>

<?php if(!empty($sso_link)): ?>
	<?php if($editor_window == 'blank'): ?>
		<script type="text/javascript">
			jQuery(document ).ready(function() {
				window.open('<?php echo $sso_link; ?>', '_blank');
			});
		</script>
	<?php elseif($editor_window == 'self'): ?>
		<div class="mobilize-dudamobile-preview">
			<iframe src="<?php echo $sso_link; ?>"></iframe>
		</div>
	<?php endif; ?>
<?php endif; ?>

<?php if(!empty($preview_url)): ?>
	<?php if($viewer_window == 'blank'): ?>
		<script type="text/javascript">
			jQuery(document ).ready(function() {
				window.open('<?php echo $preview_url; ?>', '_blank');
			});
		</script>
	<?php elseif($viewer_window == 'self'): ?>
		<div class="mobilize-dudamobile-preview">
			<iframe src="<?php echo $preview_url; ?>"></iframe>
		</div>
	<?php endif; ?>
<?php endif; ?>
