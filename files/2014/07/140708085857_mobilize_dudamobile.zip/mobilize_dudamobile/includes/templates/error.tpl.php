<div class="mobilize-dudamobile-form">
	<h3>Error of configuration</h3>
	<p>Mobilize Dudamobile setup errors. Check your plugin settings.</p>
</div>
