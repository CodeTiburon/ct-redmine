<?php

class MobilizeDudamobileError {
	private $_errors = array();

	public function __construct() {}

	public function setErrorByKey($key = '', $message = '') {
		$this->_errors[(string) $key][] = $message;
		return $this;
	}

	public function getErrorByKey($key = '') {
		if (isset($this->_errors[(string) $key])) {
			return $this->_errors[(string) $key];
		}

		return false;
	}

	public function getErrors() {
		return $this->_errors;
	}

    public function hasErrors(){
        return count($this->_errors) ? true : false;
    }
}
