<?php

abstract class MobilizeDudamobileShortcode {
	private static $_VALIDATOR_URL = 'validator_url';
	private static $_VALIDATOR_EMAIL = 'validator_email';

	public function __construct() {}

	public static function getAction($options) {
		if(empty($options['key'])) {
            add_settings_error( 'dudamobile_api_section', 'md-error-key-api', 'Invalid key "'.$options['key'].'" provided', 'error' );
			//throw new Exception('Invalid key provided');
		}
		if(empty($options['value'])) {
            add_settings_error( 'dudamobile_api_section', 'md-error-value-api', 'Invalid value "'.$options['value'].'" provided: ', 'error' );
			//throw new Exception('Invalid value provided');
		}

		return get_bloginfo('url') . '?' . (string) $options['key'] . '=' . (string) $options['value'];
	}

	public static function getSettingsByKey($key = null) {
		$settings = get_option('mobilize_dudamobile_settings');

		if (empty($settings[(string) $key])) {
            add_settings_error( 'dudamobile_api_section', 'md-error-key-api2', 'Invalid key "'.$key.'" provided', 'error' );
			//throw new Exception('Invalid key provided');
		}

		return $settings[(string) $key];
	}

	public static function getTemplatesDirectory() {
		return MOBILIZE_DUDAMOBILE_PLUGIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'templates' . DIRECTORY_SEPARATOR;
	}

	public static function _validate($value = '', $validator = NULL) {
		if(empty($value)) {
			return false;
		}

		switch ($validator) {
			case self::$_VALIDATOR_URL:
				return filter_var($value, FILTER_VALIDATE_URL);
				break;
			case self::$_VALIDATOR_EMAIL:
				return filter_var($value, FILTER_VALIDATE_EMAIL);
				break;
			default:
				return false;
				break;
		}

		return false;
	}

	public static function validator($form, $key = '') {
		$error = new MobilizeDudamobileError();

		$result = array(
			'form' => null,
			'error' => null,
		);

		switch($key) {
			case 'registration':
				if (isset($form['url']) && !self::_validate($form['url'], self::$_VALIDATOR_URL)) {
					$error->setErrorByKey($key, 'Invalid url provided');
				} else {
					!empty($form['url']) ? $form['url'] = trim($form['url']) : $form['url'] = null;
				}

				if (isset($form['email']) && !self::_validate($form['email'], self::$_VALIDATOR_EMAIL)) {
					!empty($form['email']) ? $form['email'] = trim($form['email']) : $form['email'] = null;
					$error->setErrorByKey($key, 'Invalid email provided');
				} else {
					!empty($form['email']) ? $form['email'] = trim($form['email']) : $form['email'] = null;
				}

				!empty($form['fname']) ? $form['fname'] = trim($form['fname']) : $form['fname'] = null;
				!empty($form['lname']) ? $form['lname'] = trim($form['lname']) : $form['lname'] = null;

				$result['form'] = $form;
				$result['error'] = $error;

				break;
		}

		return $result;
	}
}
