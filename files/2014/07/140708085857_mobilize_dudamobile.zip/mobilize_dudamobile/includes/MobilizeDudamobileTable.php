<?php

// WP_List_Table is not loaded automatically so we need to load it in our application
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class MobilizeDudamobileTable extends WP_List_Table
{
    protected $_columns;
    protected $_data;
    protected $_sortable;
    protected $_hidden;
    protected $_bulkActions;
    protected $_rowsPerPage = 10;
    protected $_rowsTotal;
    protected $_columnTypes;

    public function set_data($columns, $data, $rowsTotal = 0, $hidden, $sortable, $bulkActions = array(), $columnTypes = null)
    {
        $this->_columns = $columns ? $columns : array();
        $this->_data = $data ? $data : array();
        $this->_rowsTotal = $rowsTotal;
        $this->_hidden = $hidden ? $hidden : array();
        $this->_sortable = $sortable ? $sortable : array();
        $this->_bulkActions = $bulkActions ? $bulkActions : array();
        $this->_columnTypes = $columnTypes ? $columnTypes : null;
    }

    public function get_columns()
    {
        return $this->_columns ? $this->_columns : array();
    }

    public function prepare_items()
    {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $data = $this->get_table_data();
//        var_dump($data);
        if($this->_rowsTotal > 0) {
            $this->set_pagination_args( array(
                'total_items' => $this->_rowsTotal,
                'per_page'    => get_option('posts_per_page') ? (int)get_option('posts_per_page') : $this->_rowsPerPage
            ) );
        }

        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $data;
    }

    public function get_hidden_columns()
    {
        return $this->_hidden ? $this->_hidden : array();
    }

    public function get_sortable_columns()
    {
        return $this->_sortable ? $this->_sortable : array();
    }

    public function get_bulk_actions()
    {
        return $this->_bulkActions ? $this->_bulkActions : array();
    }

    public function get_table_data()
    {
        if(is_array($this->_columnTypes)) {
            $this->_data = $this->setCustomTypeToColumns($this->_data,$this->_columnTypes);
        }
        return $this->_data;
    }

    public function column_default($item, $column_name)
    {
        return $item[$column_name];
    }
    public function column_cb($item) {
        if(isset($item['site_name'])) {
            return sprintf(
                '<input type="checkbox" name="site_name[]" value="%s" />', $item['site_name']
            );
        }
        if(isset($item['account_name'])) {
            return sprintf(
                '<input type="checkbox" name="account_name[]" value="%s" />', $item['account_name']
            );
        }

        return false;
    }
    public function setCustomTypeToColumns($data, $columnNames) {
        $inputData = $data;
        foreach ($columnNames as $columnName => $columnOptions) {
            foreach($inputData as $key => $row){
                switch($columnOptions['type']) {
                    case 'url':
                        $text = (isset($columnOptions['text'])) ? $columnOptions['text'] : $row[$columnName];
                        $target = ($columnOptions['target'] === '_blank') ? $columnOptions['target'] : '_self';
                        $rowData = '<a href="'.$row[$columnName].'" target="'.$target.'">'.$text.'</a>';
                        $inputData[$key][$columnName] = $rowData;
                        break;
                }
            }
        }

        return $inputData;
    }

}
