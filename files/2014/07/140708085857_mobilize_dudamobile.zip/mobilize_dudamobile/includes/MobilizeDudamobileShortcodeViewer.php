<?php

class MobilizeDudamobileShortcodeViewer extends MobilizeDudamobileShortcode {
	public function __construct() {
		parent::__construct();
	}

	public static function getAction() {
		return parent::getAction(array(
			'key' => 'mobilize',
			'value' => self::getShortcodeKey(),
		));
	}

	public static function getShortcodeKey() {
		return md5('mobilize_dudamobile_shortcode_viewer') . '-' . md5(date('d', time()));
	}

	public function shortcode($atts, $content = '') {
		global $wpdb;

		if(!MOBILIZE_DUDAMOBILE_ENVIRONMENT_READY || !MOBILIZE_DUDAMOBILE_SETUP_READY) {
			ob_start();
			require parent::getTemplatesDirectory() . 'error.tpl.php';
			return ob_get_clean();
		}

		$shortcode_key = self::getShortcodeKey();

		extract(shortcode_atts(array(
			'viewer_window' => 'self',
		), $atts));

		$form = array();
		$errors = array();
		$result = array(
			'form' => array(
				'url',
				'email',
				'fname',
				'lname',
			),
		);

		$preview_url = null;

		$request_data = $_POST;

		if (isset($request_data['mobilize_dudamobile_registration']) && $request_data['mobilize_dudamobile_registration']['shortcode_key'] == $shortcode_key) {
			$output = self::buildViewer($request_data, array(
				'viewer_window' => isset($viewer_window) ? $viewer_window : 'self',
			));

			$errors = $output['errors'];
			$result['form'] = $output['form'];
			$preview_url = $output['preview_url'];
		}

		$action = self::getAction();

		global $wpdb;
		ob_start();
		require parent::getTemplatesDirectory() . 'registration.tpl.php';
		return ob_get_clean();
	}

	public static function buildViewer($request_data, $options = array(), $isAjaxCall = false) {
		$output = array(
			'success' => false,
		);

		!empty($options['viewer_window']) ? $viewer_window = (string) $options['viewer_window'] : $viewer_window = 'self';

		$form = $request_data['mobilize_dudamobile_registration'];

		$preview_url = null;

		if(!empty($form['url'])) {
			$form['url'] = 'http://' . str_replace(array('http://', 'www.', ), array('', '', ), $form['url']);
		}

        $mobilizeOptions = get_option('mobilize_dudamobile_settings');
        $form['email'] = $mobilizeOptions['dudamobile_anonymous_email'];
        $form['fname'] = $mobilizeOptions['dudamobile_anonymous_firstname'];
        $form['lname'] = $mobilizeOptions['dudamobile_anonymous_lastname'];
		$output['form'] = $form;

		$result = parent::validator($form, 'registration');

		$output['errors'] = $result['error']->getErrorByKey('registration');
		if(empty($output['errors'])) {
            $mdApiService = new MobilizeDudamobileApiService();

            $site = $mdApiService->createMobileSite($result['form']['url']);

			if (isset($site->error_code)) {
                return $mdApiService->getCustomErrors($site, $isAjaxCall);
			}

			$preview_url = $site->site_extra_info->preview_url;
			$output['success'] = true;
		}

		$output['preview_url'] = $preview_url;
		$output['viewer_window'] = $viewer_window;

		return $output;
	}
}
