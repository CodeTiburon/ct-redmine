<?php

class MobilizeDudamobileSettings {
	private $options;
    private $call_update_from_notice = false;

	public function __construct() {
        add_filter('pre_update_option_mobilize_dudamobile_settings', array($this, 'pre_update_option'));
		add_action('admin_menu', array($this, 'add_plugin_page'));
		add_action('admin_init', array($this, 'page_init'));
        add_action('update_option_mobilize_dudamobile_settings', array($this, 'update_option'));
        add_action('admin_menu', array($this, 'dudamobile_handle_request'));
	}

    /**
     * @access public
     * @param array $options
     * @return array $options
     */
    public function pre_update_option($options) {
        $options['dudamobile_start_caching'] = time();
        if (isset($options['from_notice'])) {
            $this->call_update_from_notice = (bool)$options['from_notice'];
            unset($options['from_notice']);
        }

        return $options;
    }

    /**
     * @access public
     */
    public function update_option() {
        $api = new MobilizeDudamobileApiService();
        $api->updateAllInfo($this->call_update_from_notice);
        setcookie('show_cache_cleared_success_notice', true, time() + 30, '/');
    }

	public function add_plugin_page() {
		add_options_page(
			'Mobilize Dudamobile Settings',
			'Mobilize Dudamobile Settings',
			'manage_options',
			'mobilize-dudamobile-settings',
			array($this, 'create_admin_page')
		);
	}

	public function create_admin_page() {
		$this->options = get_option('mobilize_dudamobile_settings');
		?>
			<div class="wrap">
				<h2>Mobilize Dudamobile Settings</h2>
				<h3>Available short codes</h3>
				<p><strong>[mobilize_dudamobile_editor]</strong> - displays a full-featured website editor</p>
				<ul>
					<li><code>editor_window = blank|self</code> open editor in new window, default <code>self</code>. <strong>Be careful</strong> - your browser can block new windows or popup windows!</li>
					<li><code>sub_account_validation = skip|check</code> skip sub account validation, default <code>skip</code></li>
				</ul>
				<p>Usage example: <code>[mobilize_dudamobile_editor]</code> or <code>[mobilize_dudamobile_editor editor_window="blank" sub_account_validation="skip"]</code> - this code will skip of user sub account validation if email already registered and will open editor in new browser window.</p>
				<p><strong>[mobilize_dudamobile_viewer]</strong> - displays a website viewer</p>
				<ul>
					<li><code>viewer_window = blank|self</code> open viewer in new window, default <code>self</code>. <strong>Be careful</strong> - your browser can block new windows or popup windows!</li>
				</ul>
				<p>Usage example: <code>[mobilize_dudamobile_viewer]</code> or <code>[mobilize_dudamobile_viewer viewer_window="blank"]</code> - this code will open viewer in new browser window.</p>
				<form method="post" action="options.php">
				<?php
					settings_fields('mobilize_dudamobile_option_group');
					do_settings_sections('mobilize-dudamobile-settings');
					submit_button();
				?>
				</form>
			</div>
		<?php
	}

	public function page_init() {
		register_setting(
			'mobilize_dudamobile_option_group',
			'mobilize_dudamobile_settings',
			array($this, 'sanitize')
		);

		add_settings_section(
			'dudamobile_api_section',
			'Dudamobile API',
			array($this, 'dudamobile_api_section_info'),
			'mobilize-dudamobile-settings'
		);
		add_settings_field(
			'dudamobile_api_endpoint',
			'API Endpoint:',
			array($this, 'dudamobile_api_endpoint_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_api_section'
		);
		add_settings_field(
			'dudamobile_api_username',
			'API Username:',
			array($this, 'dudamobile_api_username_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_api_section'
		);
		add_settings_field(
			'dudamobile_api_password',
			'API Password:',
			array($this, 'dudamobile_api_password_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_api_section'
		);

		add_settings_section(
			'dudamobile_sso_section',
			'Dudamobile SSO',
			array($this, 'dudamobile_sso_section_info'),
			'mobilize-dudamobile-settings'
		);
		add_settings_field(
			'dudamobile_sso_endpoint',
			'SSO Endpoint:',
			array($this, 'dudamobile_sso_endpoint_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_sso_section'
		);
		add_settings_field(
			'dudamobile_sso_username',
			'SSO Username:',
			array($this, 'dudamobile_sso_username_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_sso_section'
		);
		add_settings_field(
			'dudamobile_sso_password',
			'SSO Password:',
			array($this, 'dudamobile_sso_password_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_sso_section'
		);

		add_settings_section(
			'dudamobile_anonymous_section',
			'Default anonymous config',
			array($this, 'dudamobile_anonymous_section_info'),
			'mobilize-dudamobile-settings'
		);

		add_settings_field(
			'dudamobile_anonymous_email',
			'Default Email:',
			array($this, 'dudamobile_anonymous_email_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_anonymous_section'
		);

		add_settings_field(
			'dudamobile_anonymous_firstname',
			'Default Firstname:',
			array($this, 'dudamobile_anonymous_firstname_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_anonymous_section'
		);

		add_settings_field(
			'dudamobile_anonymous_lastname',
			'Default Lastname:',
			array($this, 'dudamobile_anonymous_lastname_callback'),
			'mobilize-dudamobile-settings',
			'dudamobile_anonymous_section'
		);

        add_settings_field(
            'dudamobile_cache_time',
            'Cache Time (s):',
            array($this, 'dudamobile_cache_time_callback'),
            'mobilize-dudamobile-settings',
            'dudamobile_anonymous_section'
        );


	}

	public function sanitize( $input ) {
		$new_input = array();

		if(isset($input['dudamobile_api_endpoint'])) {
			$new_input['dudamobile_api_endpoint'] = sanitize_text_field($input['dudamobile_api_endpoint']);
		}

		if(isset($input['dudamobile_api_username'])) {
			$new_input['dudamobile_api_username'] = sanitize_text_field($input['dudamobile_api_username']);
		}

		if(isset($input['dudamobile_api_password'])) {
			$new_input['dudamobile_api_password'] = sanitize_text_field($input['dudamobile_api_password']);
		}

		if(isset($input['dudamobile_sso_endpoint'])) {
			$new_input['dudamobile_sso_endpoint'] = sanitize_text_field($input['dudamobile_sso_endpoint']);
		}

		if(isset($input['dudamobile_sso_username'])) {
			$new_input['dudamobile_sso_username'] = sanitize_text_field($input['dudamobile_sso_username']);
		}

		if(isset($input['dudamobile_api_password'])) {
			$new_input['dudamobile_sso_password'] = sanitize_text_field($input['dudamobile_sso_password']);
		}

		if(isset($input['dudamobile_anonymous_email'])) {
			$new_input['dudamobile_anonymous_email'] = sanitize_text_field($input['dudamobile_anonymous_email']);
		}

		if(isset($input['dudamobile_anonymous_firstname'])) {
			$new_input['dudamobile_anonymous_firstname'] = sanitize_text_field($input['dudamobile_anonymous_firstname']);
		}

		if(isset($input['dudamobile_anonymous_lastname'])) {
			$new_input['dudamobile_anonymous_lastname'] = sanitize_text_field($input['dudamobile_anonymous_lastname']);
		}

        if(isset($input['dudamobile_cache_time'])) {
            $new_input['dudamobile_cache_time'] = sanitize_text_field($input['dudamobile_cache_time']);
        }

		return $new_input;
	}

	public function dudamobile_api_section_info() {
		print 'Enter your Dudamobile API settings below:';
	}

	public function dudamobile_sso_section_info() {
		print 'Enter your Dudamobile SSO settings below:';
	}

	public function dudamobile_anonymous_section_info() {
		print 'Enter your default anonymous settings:';
	}

	public function dudamobile_api_endpoint_callback() {
		printf(
		'<input type="text" id="dudamobile_api_endpoint" name="mobilize_dudamobile_settings[dudamobile_api_endpoint]" value="%s" />',
		isset( $this->options['dudamobile_api_endpoint'] ) ? esc_attr( $this->options['dudamobile_api_endpoint']) : ''
				);
	}

	public function dudamobile_api_username_callback() {
		printf(
		'<input type="text" id="dudamobile_api_username" name="mobilize_dudamobile_settings[dudamobile_api_username]" value="%s" />',
		isset( $this->options['dudamobile_api_username'] ) ? esc_attr( $this->options['dudamobile_api_username']) : ''
				);
	}

	public function dudamobile_api_password_callback() {
		printf(
		'<input type="text" id="dudamobile_api_password" name="mobilize_dudamobile_settings[dudamobile_api_password]" value="%s" />',
		isset( $this->options['dudamobile_api_password'] ) ? esc_attr( $this->options['dudamobile_api_password']) : ''
				);
	}

	public function dudamobile_sso_endpoint_callback() {
		printf(
		'<input type="text" id="dudamobile_sso_endpoint" name="mobilize_dudamobile_settings[dudamobile_sso_endpoint]" value="%s" />',
		isset( $this->options['dudamobile_sso_endpoint'] ) ? esc_attr( $this->options['dudamobile_sso_endpoint']) : ''
				);
	}

	public function dudamobile_sso_username_callback() {
		printf(
		'<input type="text" id="dudamobile_sso_username" name="mobilize_dudamobile_settings[dudamobile_sso_username]" value="%s" />',
		isset( $this->options['dudamobile_sso_username'] ) ? esc_attr( $this->options['dudamobile_sso_username']) : ''
				);
	}

	public function dudamobile_sso_password_callback() {
		printf(
		'<input type="text" id="dudamobile_sso_password" name="mobilize_dudamobile_settings[dudamobile_sso_password]" value="%s" />',
		isset( $this->options['dudamobile_sso_password'] ) ? esc_attr( $this->options['dudamobile_sso_password']) : ''
				);
	}

	public function dudamobile_anonymous_email_callback() {
		printf(
		'<input type="text" id="dudamobile_anonymous_email" name="mobilize_dudamobile_settings[dudamobile_anonymous_email]" value="%s" />',
		isset( $this->options['dudamobile_anonymous_email'] ) ? esc_attr( $this->options['dudamobile_anonymous_email']) : ''
				);
	}

	public function dudamobile_anonymous_firstname_callback() {
		printf(
		'<input type="text" id="dudamobile_anonymous_firstname" name="mobilize_dudamobile_settings[dudamobile_anonymous_firstname]" value="%s" />',
		isset( $this->options['dudamobile_anonymous_firstname'] ) ? esc_attr( $this->options['dudamobile_anonymous_firstname']) : ''
				);
	}

	public function dudamobile_anonymous_lastname_callback() {
		printf(
		'<input type="text" id="dudamobile_anonymous_lastname" name="mobilize_dudamobile_settings[dudamobile_anonymous_lastname]" value="%s" />',
		isset( $this->options['dudamobile_anonymous_lastname'] ) ? esc_attr( $this->options['dudamobile_anonymous_lastname']) : ''
				);
	}

    public function dudamobile_cache_time_callback() {
        printf(
            '
                <input type="number" step="10" min="0" id="dudamobile_cache_time" name="mobilize_dudamobile_settings[dudamobile_cache_time]" value="%s" />
                <span class="description">%s</span>
            ',
            isset( $this->options['dudamobile_cache_time'] ) ? esc_attr( $this->options['dudamobile_cache_time']) : '',
            'Time until the next synchronization'
                );
    }

    public function dudamobile_delete_sites(array $site_names) {
        $mdService = new MobilizeDudamobileApiService();

        foreach ($site_names as $name) {
            $mdService->deleteMobileSite($name);
        }
    }
    public function dudamobile_delete_accounts(array $accounts_names) {
        $mdService = new MobilizeDudamobileApiService();

        foreach ($accounts_names as $name) {
            $mdService->deleteAccount($name);
        }
    }

    public function dudamobile_handle_request() {
        if(isset($_POST['dudamobile-type'])) {
            $postType = strip_tags($_POST['dudamobile-type']);
            switch($postType) {
                case 'dudamobile-sites':
                    if(isset($_POST['action']) && $_POST['action'] === 'delete' || $_POST['action2'] === 'delete') {
                        $site_names = $_POST['site_name'];
                        $this->dudamobile_delete_sites($site_names);
                    }
                    break;
                case 'dudamobile-users':
                    if(isset($_POST['action']) && $_POST['action'] === 'delete' || $_POST['action2'] === 'delete') {
                        $accounts_names = $_POST['account_name'];
                        $this->dudamobile_delete_accounts($accounts_names);
                    }
                    break;
            }
        }
    }
}