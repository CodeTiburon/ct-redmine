/**
 * Created by alexandr.parkhomenko on 17.12.13.
 */
//Set click to false at beginning
var alreadyClicked = [];

chrome.browserAction.onClicked.addListener(function (tab) {

    if (!(tab.id in alreadyClicked)) {

        if (!alreadyClicked.length) {
            chrome.tabs.sendMessage(tab.id, {iframe: true}, function(response) {
                console.log('Iframe on tab - '+tab.id+' was opened !');
            });
        } else {
            chrome.tabs.sendMessage(tab.id, {createSubIframe: true}, function(response) {
                console.log('Iframe on tab - '+tab.id+' was opened !');
            });
        }
        alreadyClicked[tab.id] = true;
    } else {
        chrome.tabs.sendMessage(tab.id, {iframe: false}, function(response) {
            console.log('Iframe tab - '+tab.id+' was closed !');
        });
        alreadyClicked.splice(tab.id, 1);
    }
});

// Called when the user clicks on the browser action.
chrome.tabs.onHighlighted.addListener(function(highlightInfo) {
    console.log(highlightInfo);
    chrome.tabs.query({'active': true, 'lastFocusedWindow': true}, function (tabs) {
        var url = tabs[0].url;
        console.log(url);
    });

//    Object
//    tabIds: Array[1]
//    0: 42
//    length: 1
//    __proto__: Array[0]
//    windowId: 1

//    if (!(tabId in alreadyClicked) && alreadyClicked.length) {
//        alreadyClicked[tabId] = true;
//
////        chrome.tabs.executeScript(tabId, {
////            code: 'js/list.js',
////            runAt: 'document_start',
////            allFrames: false        // Run at the top-level frame only to get
////            // just one result
////        },function(result) {
////            if (chrome.runtime.lastError) { // or if (!result)
////                console.log(chrome.runtime.lastError);
////                // Get the error message via chrome.runtime.lastError.message
////                return;
////            }
////        });
////        chrome.tabs.executeScript(tabId, {
////            code: 'js/iframe.js',
////            runAt: 'document_start',
////            allFrames: false        // Run at the top-level frame only to get
////            // just one result
////        },function(result) {
////            if (chrome.runtime.lastError) { // or if (!result)
////                console.log(chrome.runtime.lastError);
////                // Get the error message via chrome.runtime.lastError.message
////                return;
////            }
////        });
////            chrome.tabs.executeScript(tabId, {code: "iframe.createIframe('false');"},
////                function(result) {
////                    if (chrome.runtime.lastError) { // or if (!result)
////                        console.log(chrome.runtime.lastError);
////                        // Get the error message via chrome.runtime.lastError.message
////                        return;
////                    }
////                });
//
//        chrome.tabs.sendMessage(tabId, {createSubIframe: true}, function (response) {
//            console.log('SubIframe on tab - ' + tabId + ' was opened !');
//            console.log(response);
//            if (chrome.runtime.lastError) { // or if (!result)
//                console.log(chrome.runtime.lastError);
//                // Get the error message via chrome.runtime.lastError.message
//                return;
//            }
//        });
//    }
});