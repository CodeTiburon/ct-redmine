/**
 * Created by alexandr.parkhomenko on 19.12.13.
 */
var list = {
    viewMessageId: 'ESPN_viewMessageId',
    backgroundMessageId: 'ESPN_backgroundMessageId',
    contentViewMessageId : 'contentViewMessageId'
}

var states = {
    resultReady : "resultReady",
    resultNotReady : "resultNotReady",
    resultEmpty : "resultEmpty",
    resultUpdating_onEmpty : "resultUpdating_onEmpty",
    resultUpdating_onNonEmpty : "resultUpdating_onNonEmpty"
}

var message = {
    iframeLoaded : 'Iframe loaded'
}

var localStorageId = {
    mainData : 'ESPN_Data',
    currentCategory : 'ESPN_currentCategory'
};

var urlParams = {
    initialStart : 'initialStart'
}

var dataItems = {
    type: {
        ScoreboardContainer: {
            name: "ScoreboardContainer",
            gameStatus: {
                'I': {
                    template: 'ingame',
                    fields: {
                        'VisitorTricode': 'visitor',
                        'HomeTricode': 'home',
                        'VisitorScore': 'visitor_score',
                        'HomeScore': 'home_score',
                        'GameClock': 'time',
                        'Period': 'period'
                    },
                    optional_field: {
                        templateFieldName: 'message'
                    }
                },
                'S': {
                    template: 'schedule',
                    fields: {
                        'VisitorName': 'visitor',
                        'HomeName': 'home'
                    },
                    optional_field: {
                        name: 'GameStartTime',
                        templateFieldName: 'time'
                    }
                },
                'F': {
                    template: 'postgame',
                    fields: {
                        'VisitorTricode': 'visitor',
                        'HomeTricode': 'home',
                        'VisitorScore': 'visitor_score',
                        'HomeScore': 'home_score'
                    },
                    optional_field: {
                        name: 'GameClock',
                        templateFieldName: 'message'
                    }
                },
                'O': {
                    template: 'postgame',
                    fields: {
                        'VisitorTricode': 'visitor',
                        'HomeTricode': 'home',
                        'VisitorScore': 'visitor_score',
                        'HomeScore': 'home_score'
                    },
                    optional_field: {
                        name: 'GameClock',
                        templateFieldName: 'message'
                    }
                }
            },
            'xsi: type:': {
                name: 'Pregame',
                template: 'pregame',
                fields: {
                    'GameStartTime': 'time',
                    'PregameText': 'message'
                }
            }
        },
        MessageContainer: {
            name: "MessageContainer",
            subcategory: {
                '1': {
                    template: 'message_box_with_sub'
                },
                '0': {
                    template: 'message_box'
                }
            }
        }
    }
}
