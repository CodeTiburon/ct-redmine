/**
 * Created by alexandr.parkhomenko on 17.12.13.
 */
var iframe = {

    iframeId: 'embeddedESPNWidget',
    iframeAlreadyExist: false,

    init : function () {
        this.initListening();
//        this.initListeningIframe();
    },

    initListening : function () {
        var that = this;
        chrome.runtime.onMessage.addListener(
            function(request, sender, sendResponse) {
                if (request.iframe === true && that.iframeAlreadyExist === false) {
                    that.iframeAlreadyExist = true;
                    that.createIframe(true);
                } else if (request.iframe === false && that.iframeAlreadyExist === true){
                    that.removeIframe();
                    that.iframeAlreadyExist = false;
                } else if (request.createSubIframe === true) {
                    that.iframeAlreadyExist = true;
                    that.createIframe(false);
                    sendResponse({send: "goodbye"});
                }

            });
    },

    initListeningIframe: function () {
        var port = chrome.runtime.connect();

        addEventListener("message", function(event) {

            console.log(event);
            // We only accept messages from ourselves
            if (event.source != window)
                return;

            if (event.data.type && (event.data.type == "FROM_PAGE")) {
                console.log("Content script received: " + event.data.text);
                port.postMessage(event.data.text);
            }
        }, false);
    },

    createIframe : function(initialStart) {
        var iFrame  = document.createElement("iframe");
        iFrame.src  = chrome.extension.getURL("default.html") + '?' + urlParams.initialStart + '=' + initialStart.toString();
        iFrame.id   = this.iframeId;
        iFrame.style.position = 'fixed';
        iFrame.style.bottom = 0;
        iFrame.style.left = 0;
        iFrame.style.width = '100%';
        iFrame.style.border = 0;
        iFrame.style.zIndex = 999;
        iFrame.style.height = '123px';
        document.body.appendChild(iFrame);
    },

    removeIframe: function () {
        try {
            var el = document.getElementById(this.iframeId);
            if (el) {
                document.body.removeChild(el);
            }
        } catch (e) {
//            console.log(e);
        }

    }
}
iframe.init();

