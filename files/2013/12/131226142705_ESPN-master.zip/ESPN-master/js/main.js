/**
 * Created by alexandr.parkhomenko on 18.12.13.
 */

var params = {
    limit: 7,
    updateLimit: 3,
    speed: 5000
}

// Speed up calls to hasOwnProperty
var hasOwnProperty = Object.prototype.hasOwnProperty;

function isEmpty(obj) {

    // null and undefined are "empty"
    if (obj == null) return true;

    // Assume if it has a length property with a non-zero value
    // that that property is correct.
    if (obj.length && obj.length > 0)    return false;
    if (obj.length === 0)  return true;

    // Otherwise, does it have any properties of its own?
    // Note that this doesn't handle
    // toString and toValue enumeration bugs in IE < 9
    for (var key in obj) {
        if (hasOwnProperty.call(obj, key)) return false;
    }

    return true;
}

Object.extend = function (destination, source) {
    for (var property in source)
        destination[property] = source[property];
    return destination;
};


var Board = {

    categories: null,
    dataItems: null,
    messageFunc: null,
    activeCategory: null,
    busy: false,
    queue : [],
    newData : [],
    lastUpdateDatetime: null,

    init: function (keepCurrentCategory) {
        var that = this;
        chrome.storage.local.get(localStorageId.mainData, function (items) {
            if (items) {
                Object.extend(that, items[localStorageId.mainData]);
                if (keepCurrentCategory) {
                    that.activeCategory = Object.keys(that.categories)[0];
                    that.updateCategoryBoard(true);
                    that.saveCurrentCategoryToStorage(that.activeCategory);
                    that.updateMessage();
                } else {
                    /**
                     * Get active category
                     * async process
                     */
                    chrome.storage.local.get(localStorageId.currentCategory, function (category) {
                        that.activeCategory = category[localStorageId.currentCategory];
                        that.updateCategoryBoard(true);
                        that.updateMessage();
                    });
                }
            } else {
                var compiledOutput = Handlebars.compile($j('#message_box'))({ message: 'No data from the server !'});
                $j('#base_container').html(compiledOutput);
                console.log("No data");
            }
        });

    },

    update : function (data) {
        Object.extend(this, data);
        /**
         * Check if current active category present in new data
         */
        if (this.categories[this.activeCategory] == undefined) {
            this.activeCategory = Object.keys(this.categories)[0];
        }
        this.updateCategoryBoard(false);
        this.updateMessage();
        console.log('Board was updated !');
    },

    setBusy : function (busy) {

        if (busy) this.busy = true;
        else {
            this.busy = false;
            if ('update' in this.queue) {
                this.queue.splice('update', 1);
                this.update(this.newData);
            }
        }
    },

    updateCategoryBoard: function (init) {

        var html = '';
        var that = this;
        var activeCategory = this.activeCategory.toString();
        var style = '';
        if (init){
            style = ' style="right: -'+$j(document).width()+'px;" ';
        }
        $j.each(this.categories, function (index, item) {
            if (activeCategory === index) {
                $j('#current-category').hide();
                $j('#current-category span').text(item);
                html += '<li class="active" data-id="' + index + '"' + style +'><span>' + item + '</span></li>';
            } else {
                html += '<li data-id="' + index + '"'+style+'><span>' + item + '</span></li>';
            }
        });

        $j('#menu ul').html(html);
        setTimeout(function () {
            that.updateCategoryContainer($j('#menu li[data-id="' + activeCategory + '"]'));
            /**
             * Force browser to re-render element
             */
            $j('#current-category').show();
        }, 5);

    },

    updateMessage: function () {

        var categoryId = $j('#menu li.active').data('id');
        var currentMessages = this.dataItems[categoryId];
        var lengthMessages = currentMessages.length;
        var index = 0;
        var that = this;
        var isNonValidCategory = false;

        if (this.messageFunc !== null) {
            clearInterval(this.messageFunc);
        }

        var sourceObject = false;
        do {
            sourceObject = that.checkMessageType(currentMessages[index]);
            if (index === lengthMessages - 1 && sourceObject === false) {
                isNonValidCategory = true;
            } else {
                index++;
            }
        } while (sourceObject === false && isNonValidCategory === false)

        /**
         * Check if category has valid message
         */
        if (isNonValidCategory) {
            var compiledOutput = Handlebars.compile($j('#message_box'))({ message: 'No results in this category !'});
            $j('#base_container').html(compiledOutput);
            return false;
        }

        this.checkIfMessageHasSameTypeAsPrevious(sourceObject.template, sourceObject.object);

        var compiledOutput = Handlebars.compile($j('#'+sourceObject.template).html())(sourceObject.object);
        $j('#base_container').html(compiledOutput);

        this.messageFunc = setInterval(function () {
            that.setBusy(true);
            var sourceObject = false;
            while (!sourceObject) {
                sourceObject = that.checkMessageType(currentMessages[index]);
                if (index === lengthMessages - 1) {
                    index = 0;
                } else {
                    index++;
                }
            }
            that.checkIfMessageHasSameTypeAsPrevious(sourceObject.template, sourceObject.object);
            TweenLite.to($j('#base'), 3, {css: {top: -60}, ease: Power2.easeOut});
            setTimeout(function () {
                var compiledOutput = Handlebars.compile($j('#'+sourceObject.template).html())(sourceObject.object);
                $j('#base_container').html(compiledOutput);
                that.setBusy(false);
            }, 1000);

        }, params.speed);
    },

    checkIfMessageHasSameTypeAsPrevious : function (message_id, object) {
        if ($j('#base').length && $j('#base').data('type') === message_id) {
            console.log('The same type');
        } else {
            console.log('Not the same type');
        }
    },

    /**
     *
     * @param string
     * @returns {*}
     */
    cutColorAttribute: function (string) {
        /**
         * @todo Check is it string
         */
        var lastColorCharIndex = string.indexOf('>');
        if (lastColorCharIndex) {
            string = string.substr(lastColorCharIndex + 1);
        }
        return string;
    },

    checkMessageType: function (messageItem) {

        if (messageItem == undefined)
            return false;

        if (messageItem.itemType == undefined)
            return false;

        var preparedItem = undefined;
        var objectItem = {};
        var output = {};
        var that = this;
        /**
         * isValid will be false if some of required fields are not exist
         * @type {boolean}
         */
        var isValid = true;

        switch (messageItem.itemType) {
            case dataItems.type.ScoreboardContainer.name :

                preparedItem = messageItem.itemValue[dataItems.type.ScoreboardContainer.name].Scoreboard;

                if (preparedItem == undefined)
                    return false;

                $j.each(dataItems.type.ScoreboardContainer.gameStatus, function (index, value) {
                    if (index === preparedItem.GameStatus) {
                        $j.each(value.fields, function (item_index, item_value) {
                            /**
                             * Check if all required attributes are presents
                             */
                            if (preparedItem[item_index] == undefined) {
                                isValid = false;
                                return false;
                            }
                            objectItem[item_value] = index === "F" ? that.cutColorAttribute(preparedItem[item_index]) : preparedItem[item_index];
                        });

                        if (index !== 'I' && preparedItem[value.optional_field.name] != undefined) {
                            objectItem[value.optional_field.templateFieldName] = preparedItem[value.optional_field.name];
                        } else if (
                            messageItem.itemValue[dataItems.type.ScoreboardContainer.name].ScoreboardMessage != undefined &&
                                messageItem.itemValue[dataItems.type.ScoreboardContainer.name].ScoreboardMessage.DetailItems.MessageDetailItem.DetailText != undefined) {
                            objectItem[value.optional_field.templateFieldName] = messageItem.itemValue[dataItems.type.ScoreboardContainer.name].ScoreboardMessage.DetailItems.MessageDetailItem.DetailText;
                        }

                        output = { object: objectItem, template: value.template };
                    }
                });


                if (isEmpty(output)) {
                    /**
                     * Check if not PREGAME type
                     */
                    if (preparedItem['xsi: type:'] != dataItems.type.ScoreboardContainer['xsi: type:'].name
                        && preparedItem['xsi:type'] != dataItems.type.ScoreboardContainer['xsi: type:'].name) return false;

                    isValid = true;

                    $j.each(dataItems.type.ScoreboardContainer['xsi: type:'].fields, function (item_index, item_value) {
                        if (preparedItem[item_index] == undefined) {
                            isValid = false;
                            return false;
                        }

                        objectItem[item_value] = preparedItem[item_index];
                    });
                    output = { object: objectItem, template: dataItems.type.ScoreboardContainer['xsi: type:'].template };
                }

                if (isValid)
                    return output;

                return isValid;

            case  dataItems.type.MessageContainer.name :

                preparedItem = messageItem.itemValue[dataItems.type.MessageContainer.name].MessageList.Message;
                var isSubExist = 0;
                var subText = '';

                if (preparedItem.TabText != undefined) {
                    isSubExist = 1;
                    subText = preparedItem.TabText;
                }

                if (preparedItem.DetailItems.MessageDetailItem.RecordText != undefined) {
                    isSubExist = 1;
                    subText = preparedItem.DetailItems.MessageDetailItem.RecordText;
                }

                objectItem = {
                    subExist: isSubExist,
                    message: preparedItem.DetailItems.MessageDetailItem.DetailText,
                    sub: subText
                }

                output = { object: objectItem, template: dataItems.type.MessageContainer.subcategory[isSubExist.toString()].template };
                return output;
        }
    },

    updateCategory: function (newCategoryId, oldCategoryId) {
        this.setBusy(true);
        if (oldCategoryId) {
            $j('#menu li[data-id="' + oldCategoryId + '"]').removeClass('active');
        }
        this.activeCategory = newCategoryId;
        var currentCategoryEl = $j('#menu li[data-id="' + newCategoryId + '"]');
        this.updateCategoryContainer(currentCategoryEl);
        $j('#current-category span').text(currentCategoryEl.text());
        currentCategoryEl.addClass('active');
        this.updateMessage();
        this.setBusy(false);
    },

    updateCategoryContainer: function (currentCategoryEl) {

        var selector;
        var appendToSelector = '';
        var elementIndex = currentCategoryEl.index();
        var shift = Math.floor(elementIndex / params.updateLimit);
        var startEl = shift * params.updateLimit;
        var endEl = startEl + params.limit;
        if (shift > 0) {
            appendToSelector = ':gt("' + (startEl - 1) + '")';
            TweenLite.to($j('#menu li'), 1, {css: {right: (this.calcWidth('#menu li:lt("' + startEl + '")'))}, ease: Power2.easeOut});
        } else {
            TweenLite.to($j('#menu li'), 1, {css: {right: 0}, ease: Power2.easeOut});
        }
        selector = '#menu li:lt("' + endEl + '")' + appendToSelector;
        $j('#menu').css({width: this.calcWidth(selector)});
    },

    calcWidth: function (selector) {
        var calcWidth = 0;
        $j.each($j(selector), function () {
            calcWidth += $j(this).outerWidth(true);
        });
        return calcWidth;
    },

    saveCurrentCategoryToStorage: function (currentCategoryId) {
        var storageData = {};
        storageData[localStorageId.currentCategory] = currentCategoryId;
        chrome.storage.local.set(storageData);
    },

    getURLParameter: function (name) {
        return decodeURI(
            (RegExp(name + '=' + '(.+?)(&|$)').exec(location.search) || [, null])[1]);
    }
}

Board.init(Board.getURLParameter(urlParams.initialStart) === 'true');

$j('body').on('click', '#manage-track .arrow', function () {
    var current = $j('#menu li.active');
    var newCurrent = null;
    var parent = current.parents('#menu');
    if ($j(this).hasClass('prev')) {
        if (current.index() === 0) {
            newCurrent = current.siblings(':last');
        } else {
            newCurrent = current.prev('li');
        }
    } else {
        if (parent.find('li').length - 1 === current.index()) {
            newCurrent = current.siblings(':first');
        } else {
            newCurrent = current.next('li');
        }
    }
    Board.saveCurrentCategoryToStorage(newCurrent.data('id'));
});

chrome.storage.onChanged.addListener(function (changes, namespace) {
    if (namespace === 'local') {
        for (key in changes) {
            if (key === localStorageId.currentCategory) {
                var storageChange = changes[key];
                Board.updateCategory(storageChange.newValue, storageChange.oldValue);
                if (key === localStorageId.mainData) Board.updateData();
            } else if (key === localStorageId.mainData) {
                var storageChange = changes[key];
                if (!Board.busy && (storageChange.newValue.datetime - storageChange.oldValue.datetime) > 10) {
                    Board.update(storageChange.newValue);
                } else if (Board.busy){
                    Board.queue['update'] = true;
                    Board.newData = storageChange.newValue;
                }
            }
        }
    }
});