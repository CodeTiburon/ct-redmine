/**
 * Created by alexandr.parkhomenko on 17.12.13.
 */
var iframe = {

    iframeId: 'embeddedESPNWidget',

    init : function () {
        this.initListening();
    },

    initListening : function () {
        var that = this;
        chrome.runtime.onMessage.addListener(
            function(request, sender, sendResponse) {
                if (request.iframe === true) {
                    that.createIframe();
                } else {
                    that.removeIframe();
                }
//                sendResponse({send: "goodbye"});
            });
    },
    createIframe : function() {
        var iFrame  = document.createElement ("iframe");
        iFrame.src  = chrome.extension.getURL ("1.html");
        iFrame.id   = this.iframeId;
        iFrame.style.position = 'fixed';
        iFrame.style.bottom = 0;
        iFrame.style.width = '100%';
        iFrame.style.border = 0;
        iFrame.style.zIndex = 999;
        (document.documentElement).appendChild(iFrame);
    },

    removeIframe: function () {
        var el = document.getElementById(this.iframeId);
        document.documentElement.removeChild(el);
    }
}
iframe.init();