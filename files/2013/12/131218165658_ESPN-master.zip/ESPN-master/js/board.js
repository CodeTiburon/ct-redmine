/**
 * Created by alexandr.parkhomenko on 17.12.13.
 */
var Board =  {

    request: null,
    xhr: null,
    baseUrl: 'http://api.espn.com/2016/blcrux/v1/espn/playlist/lastActive?embedded=true&apikey=8ywhpt54vp5qe73dxhvq3sns',
    relativeUrl: '',
    state: null,
    queue: [],
    requestId: null,
    currentCategory: null,
    categories: [],

    init: function() {
//        request = new XMLHttpRequest();
//        this.lookingNewData();
    },

    initRequest: function() {
        var request = new XMLHttpRequest();
        this.request = request;
        request = new XMLHttpRequest();
        request.open("GET", this.url, true);
        request.onreadystatechange = this.processResponse;
        request.send();
    },

    lookingNewData:  function () {

    },

    processResponse: function () {
        console.log(this.request);
        if (this.request.readyState == 4)
            if (this.request.status == 200)
                alert("Server is done!");
    },

    getAnotherPages: function () {

    }

}

//Board.init();
