/**
 * Created by alexandr.parkhomenko on 17.12.13.
 */
//Set click to false at beginning
var alreadyClicked = [];

chrome.browserAction.onClicked.addListener(function (tab) {

    if (!(tab.id in alreadyClicked)) {

        chrome.tabs.sendMessage(tab.id, {iframe: true}, function(response) {
            console.log('Iframe was opened !');
        });
        alreadyClicked[tab.id] = true;
    } else {
        chrome.tabs.sendMessage(tab.id, {iframe: false}, function(response) {
            console.log('Iframe was closed !');
        });
        alreadyClicked.splice(tab.id, 1);
    }
});